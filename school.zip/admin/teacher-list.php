<?php


include "../functions/rep.php";



if(isset($_GET["deleteerror"]))
{
  $deleteerror="خطا در عملیات حذف معلم.";
}
if(isset($_GET["deleteok"]))
{
  $deleteok="معلم با موفقیت حذف شد";
}



?>


<!DOCTYPE html>
<html lang="en">
<head>


  <title>پنل مدیریت : <?php echo $fullname; ?></title>

  <?php
  include "head.php";
  ?>

</head>

<body>

<section id="container" class="">

  <!--header start-->
  <?php include ("header.php"); ?>
  <!--header end-->


  <!--sidebar start-->
  <?php include ("sidebar.php"); ?>
  <!--sidebar end-->


  <!--main content start-->
  <section id="main-content">

    <section class="wrapper">
      <!-- page start-->



      <div class="row">
        <div class="col-lg-12">




          <?php
          if(isset($deleteok) && $deleteok!="")
          {
            ?>
            <div class="alert alert-success alert-block fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <h4>
                <i class="icon-ok-sign"></i>
                موفق!
              </h4>
              <p><?=$deleteok;?></p>
            </div>
            <?php
          }
          ?>



          <?php
          if(isset($deleteerror) && $deleteerror!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong><?=$deleteerror;?></strong>

            </div>
            <?php
          }
          ?>




          <section class="panel">



            <div class="inbox-head">
              <h3 style="float:right; font-weight:bold;margin-left:10px;">جستجو</h3>
              <form class="pull-right position" method="post" style="width:40%;">
                <div class="input-append">
                  <input type="text" id="teaname" name="srch" placeholder="نام و نام خانوادگی معلم" class="sr-input" style="width:70%; ">
                  <input type="submit" name="srchstud" class="btn sr-btn" value="بگرد">
                </div>
              </form>
            </div>



            <header class="panel-heading">

              لیست کل معلمین

            </header>
            <table class="table table-striped table-advance table-hover">
              <thead>
              <tr>
                <th>#</th>
                <th>نام و نام خانوادگی</th>
                <th>کد پرسنلی</th>
                <th>کد ملی</th>
                <th>مدرک</th>
                <th>رشته</th>
                <th>تلفن</th>
                <th>تصویر معلم</th>
                <th>عملیات</th>
              </tr>
              </thead>
              <tbody id="htmldata">

              </tbody>
            </table>
          </section>


          <?php
          if(isset($erorr) && $erorr!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong><?=$erorr;?></strong>

            </div>
            <?php
          }
          ?>


        </div>
      </div>
      <!-- page end-->


    </section>

    <script type="text/javascript">
      function del(id)
      {
        var x=confirm("آیا از حذف معلم اطمینان دارید؟");
        if(x==true)
        {
          window.location.href="teacher-delete.php?id="+id;
        }
        else
        {
          window.location.href="#";
        }
      }
    </script>


  </section>
  <!--main content end-->

</section>


<!-- js placed at the end of the document so the pages load faster -->
<script src="../styles/js/jquery.js"></script>
<script src="../styles/js/jquery-1.8.3.min.js"></script>
<script src="../styles/js/bootstrap.min.js"></script>
<script src="../styles/js/jquery.scrollTo.min.js"></script>
<script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
<script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
<script src="../styles/js/owl.carousel.js" ></script>
<script src="../styles/js/jquery.customSelect.min.js" ></script>

<!--common script for all pages-->
<script src="../styles/js/common-scripts.js"></script>

<!--script for this page-->
<script src="../styles/js/sparkline-chart.js"></script>
<script src="../styles/js/easy-pie-chart.js"></script>

<script>

  //owl carousel

  $(document).ready(function() {
    $("#owl-demo").owlCarousel({
      navigation : true,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem : true

    });
  });

  //custom select box

  $(function(){
    $('select.styled').customSelect();
  });
</script>



<script>
  $(function(){
    $(document).ready(function()
    {

      var value = $(this).val();

      $.ajax(
        'search-feed.php',
        {
          type: 'get',
          dataType: 'json',

          data: {
            keyword: value,
            tea: true
          },

          success: function(data)
          {
            ajaxResult(data);
          }//success
        }//ajax object
      );//ajax
    });
  });//function
</script>




<script>
  $(function(){
    $('#teaname').on('keyup',function()
    {

      var value = $(this).val();

      $.ajax(
        'search-feed.php',
        {
          type: 'get',
          dataType: 'json',

          data: {
            keyword: value,
            tea: true
          },

          success: function(data)
          {
            ajaxResult(data);
          }//success
        }//ajax object
      );//ajax
    });
  });//function
</script>


<script>
  function ajaxResult(data)
  {
    var records = data.raw;
    var html = '';
    var co = 0;
    for (var i in records)
    {
      co++;
      var record = records[i];

      var teaimg = "<img src='../"+ record.img +"' width='45' height='50'>";
      var fullname = "<a href='teachers-info.php?id="+ record.username +"'>"+ record.fullname +"</a>";
      var sendmsg = "<a class='btn btn-success btn-xs' href='teacher-send-message.php?id="+ record.username +"'><i class='icon-envelope'>ارسال پیام</i></a>";
      var teaedit = "<a class='btn btn-primary btn-xs' style='color:#fff;' href='teacher-edit.php?id="+ record.id +"'><i class='icon-pencil'>ویرایش</i></a>";
      var teadelete = "<a class='btn btn-danger btn-xs' style='color:#fff;' onClick='del("+ record.id +")'><i class='icon-trash'>حذف</i></a>";

      html +=
        '<tr>' +
        '<td>' + co + '</td>' +
        '<td>' + fullname + '</td>' +
        '<td>' + record.username + '</td>' +
        '<td>' + record.ncode + '</td>' +
        '<td>' + record.madrak + '</td>' +
        '<td>' + record.reshte + '</td>' +
        '<td>' + record.tell + '</td>' +
        '<td>' + teaimg + '</td>' +

        '<td>' + sendmsg + teaedit + teadelete + '</td>' +
        '</tr>';
    }//for
    $("#htmldata").html(html);
  }
</script>


</body>
</html>