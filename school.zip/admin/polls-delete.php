<?php

if(isset($_GET['id']))
{
	include "../functions/connection.php";
	$sql = "DELETE FROM `tbl_polls` WHERE `tbl_polls`.`id` = '".$_GET['id']."'";
	$query = mysqli_query($con,$sql);
	if($query)
	{
		header("location:polls-list.php?deleteok=3645");
		exit;
	}
	else
	{
		header("location:polls-list.php?deleteerror=9442");
		exit;	
	}
}
else
{
	header ("location:index.php");
	exit;
}

?>