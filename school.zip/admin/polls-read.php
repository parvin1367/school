<?php

include "../functions/rep.php";

if(isset($_GET["id"]))
{
	if(isset($_GET["flag"]) && $_GET["flag"]==1)
	{
		$sqlupdt="UPDATE `tbl_polls` SET `state` = '0' WHERE `tbl_polls`.`id` = '".$_GET["id"]."';";
		$queryupdt=mysqli_query($con,$sqlupdt);	
	}
	
}
else
{
	header("location:index.php");
	exit;
}

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

	<?php
	include "head.php";
	?>
    
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
		<section id="main-content">
            <section class="wrapper">
                <!-- page start-->
                <div class="row">
				
				<?php
					$sql="select * from tbl_polls where id='".$_GET["id"]."'";
					$query=mysqli_query($con,$sql);
					$fetch=mysqli_fetch_assoc($query);
				?>
				
				
					<div class="col-lg-6" style="width:99%;margin-top:40px;">
					
					

					
					
                        <section class="panel">
                            <header class="panel-heading">
                                
								<b><?php echo $fetch["title"]; ?></b>
                         
                            </header>
                            <div class="panel-body profile-activity">
                                <h5 class="pull-right"></h5>
                                <div class="activity blue">
                                    <span>
                                        <i class="icon-bullhorn"></i>
                                    </span>
                                    <div class="activity-desk">
                                        <div class="panel">
                                            <div class="panel-body">
                                                <div class="arrow"></div>
                                                <i class=" icon-time"></i>
                                                <h4><b><?php echo $fetch["date"]; ?></b></h4>
                                                <p><?php echo $fetch["text"]; ?></p>
                                            </div>
                                        </div>
                                    </div>
									<a class="btn btn-danger" href="polls-delete.php?id=<?php echo $_GET["id"] ?>" >حذف کردن</a>
                                </div>

                                
								
								
								
								
								
								

                            </div>
                        </section>
                    </div>
					
					
					
					
				</div>
			</section>
        </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
