<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">
                  <li class="active">
                      <a class="" href="index.php">
                          <i class="icon-home"></i>
                          <span>صفحه اصلی</span>
                      </a>
                  </li>
                  
                  
                  <li>
                      <a class="" href="news-insert.php">
                          <i class="icon-bullhorn"></i>
                          <span>مدیریت اخبار</span>
                      </a>
                  </li>
				  
				  
				  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon-envelope-alt"></i>
						  
						  <?php
							$msg=0;
							$sqlmsg="select * from tbl_messages where `to`='1' AND `state`='1'";
							$querymsg=mysqli_query($con,$sqlmsg);
							$countmsg=mysqli_num_rows($querymsg);
							$sqlmsg2="select * from tbl_messages_stu where `to`='1' AND `state`='1'";
							$querymsg2=mysqli_query($con,$sqlmsg2);
							$countmsg2=mysqli_num_rows($querymsg2);
							if($countmsg>0 || $countmsg2>0)
							{
								$msg=$countmsg+$countmsg2;
							}
						  ?>
						  
						  <span class="label label-danger pull-right mail-info"><?php if($msg>0) {echo $msg;} ?></span>
                          <span>مدیریت پیام ها</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="teacher-recived-messages.php">دریافت شده از معلمان</a></li>
						  <li><a class="" href="teacher-sent-messages.php">ارسال شده به معلمان</a></li>
						  
						  <li><a class="" href="student-recived-messages.php">دریافت شده از دانش</a></li>
						  <li><a class="" href="student-sent-messages.php">ارسال شده به دانش</a></li>
                      </ul>
                  </li>
				  
				  
				  
				  
				  <li class="sub-menu">
						  <?php
							$msg=0;
							$sqlpl="select * from tbl_polls where `state`='1'";
							$querypl=mysqli_query($con,$sqlpl);
							$countpl=mysqli_num_rows($querypl);
						  ?>
						<a class="" href="polls-list.php">
						  <span class="label label-danger pull-right mail-info"><?php if($countpl>0) {echo $countpl;} ?></span>
                          <i class="icon-comments-alt"></i>
                          <span>نظرات و پیشنهادات</span>
                        </a>
                  </li>
                  
				  
                  
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon-user"></i>
                          <span>مدیریت دانش آموزان</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="student-insert.php">افزودن دانش آموز</a></li>
                          <li><a class="" href="student-list.php">لیست دانش آموزان</a></li>
                      </ul>
                  </li>
                  
                  
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon-user"></i>
                          <span>مدیریت معلمان</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="teacher-insert.php">افزودن معلم</a></li>
                          <li><a class="" href="teacher-list.php">لیست معلمان</a></li>
                      </ul>
                  </li>
                  
                  
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon-book"></i>
                          <span>مدیریت دروس</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
						<li><a class="" href="course.php">ثبت درس جدید</a></li>
                        <li><a class="" href="course-list.php">لیست دروس</a></li>
                      </ul>
                  </li>
				  
				  
				  
				  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon-file-text"></i>
                          <span>مدیریت برنامه هفتگی</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="proweek-insert.php">تنظیم برنامه هفتگی</a></li>
                          <li><a class="" href="proweek-list.php">مشاهده لیست برنامه</a></li>
                      </ul>
                  </li>
				  
				  
				  
				  <li>
                      <a class="" href="nomre-archive.php">
                          <i class="icon-tasks"></i>
                          <span>آرشیو ارزشیابی</span>
                      </a>
                  </li>
                  
                  
                  
                  <li>
                      <a class="" href="admin-logout.php">
                          <i class="icon-off"></i>
                          <span>خروج از حساب مدیریت</span>
                      </a>
                  </li>
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>