<?php

if(isset($_GET['id']))
{
	include "../functions/connection.php";
	$sql = "DELETE FROM `tbl_teachers` WHERE `tbl_teachers`.`id` = '".$_GET['id']."'";
	$query = mysqli_query($con,$sql);
	if($query)
	{
		header("location:teacher-list.php?deleteok=215");
		exit;
	}
	else
	{
		header("location:teacher-list.php?deleteerror=9815");
		exit;	
	}
}
else
{
	header ("location:index.php");
	exit;	
}

?>