<?php


include "../functions/rep.php";



if(isset($_POST['insert-course']))
{
  if($_POST['name']!="")
  {


    $name = myPrevent($_POST["name"]);
    $payeid = myPrevent($_POST["payeid"]);
    $reshteid = myPrevent($_POST["reshteid"]);
    $teacherid = myPrevent($_POST["teacherid"]);



    $sql="INSERT INTO `tbl_course` (`id`, `name` , `payeid`, `reshteid`, `teacherid`) VALUES (NULL, '".$name."' , '".$payeid."', '".$reshteid."', '".$teacherid."')";


    $query=mysqli_query($con,$sql);
    if($query)
    {
      $success = "درس با موفقیت ثبت شد.";
    }
    else
    {
      $erorr = "خطا در عملیات ثبت";
    }


  }
  else
  {
    if($_POST['name'] == "") $texterror = "لطفا نام درس را وارد کنید.";
  }
}
else
{

}


if(isset($_GET["deleteerror"]))
{
  $deleteerror="خطا در عملیات حذف درس.";
}
if(isset($_GET["deleteok"]))
{
  $deleteok="درس با موفقیت حذف شد.";
}

?>


<!DOCTYPE html>
<html lang="en">
<head>


  <title>پنل مدیریت : <?php echo $fullname; ?></title>

  <?php
  include "head.php";
  ?>

</head>

<body>

<section id="container" class="">

  <!--header start-->
  <?php include ("header.php"); ?>
  <!--header end-->


  <!--sidebar start-->
  <?php include ("sidebar.php"); ?>
  <!--sidebar end-->


  <!--main content start-->
  <section id="main-content">

    <section class="wrapper">
      <!-- page start-->



      <div class="row">

        <div class="col-lg-6" style="width:100%;">



          <?php
          if(isset($success) && $success!="")
          {
            ?>
            <div class="alert alert-success alert-block fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <h4>
                <i class="icon-ok-sign"></i>
                موفق!
              </h4>
              <p><?=$success;?></p>
            </div>
            <?php
          }
          ?>





          <?php
          if(isset($deleteok) && $deleteok!="")
          {
            ?>
            <div class="alert alert-success alert-block fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <h4>
                <i class="icon-ok-sign"></i>
                موفق!
              </h4>
              <p><?=$deleteok;?></p>
            </div>
            <?php
          }
          ?>



          <?php
          if(isset($deleteerror) && $deleteerror!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong><?=$deleteerror;?></strong>

            </div>
            <?php
          }
          ?>





          <?php
          if(isset($erorr) && $erorr!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong><?=$erorr;?></strong>

            </div>
            <?php
          }
          ?>




          <?php
          if(isset($texterror) && $texterror!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong>خطا در انجام عملیات : </strong> <?=$texterror;?>

            </div>
            <?php
          }
          ?>




          <section class="panel">
            <header class="panel-heading">
              ثبت درس جدید

            </header>
            <div class="panel-body">


              <form role="form" method="post">


                <div class="form-group">
                  <label for="exampleInputEmail1">نام درس</label>
                  <input name="name" type="text" class="form-control" id="exampleInputEmail1" >
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">پایه:</label>
                  <select name="payeid" style="width:100%">
                    <option value="7">هفتم</option>
                    <option value="8">هشتم</option>
                    <option value="9">نهم</option>
                    <option value="2">دوم دبیرستان</option>
                    <option value="3">سوم دبیرستان</option>
                  </select>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">رشته:</label>
                  <select name="reshteid" style="width:100%">
                    <option value="عمومی">عمومی</option>
                    <option value="انسانی">علوم انسانی</option>
                    <option value="تجربی">علوم تجربی</option>
                    <option value="ریاضی">ریاضی</option>
                  </select>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">مدرس:</label>
                  <select name="teacherid" style="width:100%">

                    <?php
                    $teachersql="select * from tbl_teachers order by `id` desc";
                    $teacherquery=mysqli_query($con,$teachersql);
                    while($teacherfetch=mysqli_fetch_assoc($teacherquery))
                    {
                      echo "<option value=".$teacherfetch["username"].">".$teacherfetch["fullname"]."</option>";
                    }
                    ?>

                  </select>
                </div>



                <br>

                <input type="submit" name="insert-course" class="btn btn-info" value="ثبت درس">
                <button class="btn btn-default" type="reset">پاک کردن فرم</button>
              </form>

            </div>
          </section>
        </div>

      </div>





      <div class="row">
        <div class="col-lg-12">
          <section class="panel">
            <header class="panel-heading">

              لیست دروس

            </header>
            <table class="table table-striped table-advance table-hover">
              <thead>
              <tr>
                <th>نام درس</th>
                <th class="hidden-phone">پایه</th>
                <th>رشته</th>
                <th>مدرس</th>
                <th>عملیات</th>
              </tr>
              </thead>
              <tbody>

              <?php

              $sql = "select * from tbl_course order by `id` desc";
              $query = mysqli_query($con,$sql);
              while($fetch = mysqli_fetch_assoc($query))
              {
                echo "<tr>";
                echo "<td>".$fetch["name"]."</td>";
                echo "<td>".$fetch["payeid"]."</td>";
                echo "<td>".$fetch["reshteid"]."</td>";

                $sqlteacher="select `fullname` from tbl_teachers where `username`='".$fetch["teacherid"]."'";
                $queryteacher=mysqli_query($con,$sqlteacher);
                $fetchteacher=mysqli_fetch_assoc($queryteacher);
                if(mysqli_num_rows($queryteacher)>0)
                {
                  echo "<td>".$fetchteacher["fullname"]."</td>";
                }
                else
                {
                  echo "-";
                }

                $x=$fetch["id"];

                echo "<td>


									<button class='btn btn-success btn-xs'><i class='icon-ok'></i></button>



									<a class='btn btn-danger btn-xs' style='color:#fff;' onClick='del($x)'><i class='icon-trash'>"." "."حذف</i></a>


									</td>";
                echo "</tr>";
              }

              ?>

              <!--
              <a class='btn btn-primary btn-xs' style='color:#fff;' href=course-edit.php?id=".$fetch["id"]."><i class='icon-pencil'>"." "."ویرایش</i></a>
              -->

              </tbody>
            </table>
          </section>
        </div>
      </div>
      <!-- page end-->


    </section>

    <script type="text/javascript">
      function del(id)
      {
        var x=confirm("آیا از حذف درس اطمینان دارید؟");
        if(x==true)
        {
          window.location.href="course-delete.php?id="+id;
        }
        else
        {
          window.location.href="#";
        }
      }
    </script>


  </section>
  <!--main content end-->

</section>


<!-- js placed at the end of the document so the pages load faster -->
<script src="../styles/js/jquery.js"></script>
<script src="../styles/js/jquery-1.8.3.min.js"></script>
<script src="../styles/js/bootstrap.min.js"></script>
<script src="../styles/js/jquery.scrollTo.min.js"></script>
<script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
<script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
<script src="../styles/js/owl.carousel.js" ></script>
<script src="../styles/js/jquery.customSelect.min.js" ></script>

<!--common script for all pages-->
<script src="../styles/js/common-scripts.js"></script>

<!--script for this page-->
<script src="../styles/js/sparkline-chart.js"></script>
<script src="../styles/js/easy-pie-chart.js"></script>

<script>

  //owl carousel

  $(document).ready(function() {
    $("#owl-demo").owlCarousel({
      navigation : true,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem : true

    });
  });

  //custom select box

  $(function(){
    $('select.styled').customSelect();
  });

</script>

</body>
</html>
