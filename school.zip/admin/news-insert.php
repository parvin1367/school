<?php


include "../functions/rep.php";



	if(isset($_POST['insert-news']))
	{
		if($_POST['title']!="" && $_POST['text']!="")
		{
			
			
			$to = myPrevent($_POST["to"]);
			$title = myPrevent($_POST["title"]);
			$text = myPrevent($_POST["text"]);
			

			
			$sql="INSERT INTO `tbl_news` (`id`, `to`, `title`, `text`,`date`,`time`) VALUES (NULL, '".$to."', '".$title."', '".$text."','".$mydate."','".$mytime."')";
			
			
			$query=mysqli_query($con,$sql);
			if($query)
			{
				$success = "خبر با موفقیت ثبت شد.";
			}
			else
			{
				$erorr = "خطا در عملیات ثبت";
			}
			
				
		}
		else
		{
			if($_POST['title'] == "") $titleerorr = "لطفا عنوان خبر را وارد کنید";
			if($_POST['text'] == "") $texterror = "لطفا متن خبر را وارد کنید";
		}
	}
	else
	{
		
	}
	
	if(isset($_GET["updateok"]))
	{
		$editok="خبر با موفقیت ویرایش شد.";
	}
	if(isset($_GET["deleteok"]))
	{
		$deleteok="خبر با موفقیت حذف شد.";
	}
	
	
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

	<?php
	include "head.php";
	?>
    
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
      <section id="main-content">
      
      <section class="wrapper">
                <!-- page start-->
                
				
                
                <div class="row">
                
                    <div class="col-lg-6" style="width:100%;">
                    
                    
                    
                 			   <?php
								if(isset($success) && $success!="")
								{
								?>
                   				 <div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4>
                                        <i class="icon-ok-sign"></i>
                                        موفق!
                                  </h4>
                                    <p><?=$success;?></p>
                                </div>
                                <?php
								}
								?>
								
								
								<?php
								if(isset($deleteok) && $deleteok!="")
								{
								?>
                   				 <div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4>
                                        <i class="icon-ok-sign"></i>
                                        موفق!
                                  </h4>
                                    <p><?=$deleteok;?></p>
                                </div>
                                <?php
								}
								?>
								
								
								
								<?php
								if(isset($editok) && $editok!="")
								{
								?>
                   				 <div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4>
                                        <i class="icon-ok-sign"></i>
                                        موفق!
                                  </h4>
                                    <p><?=$editok;?></p>
                                </div>
                                <?php
								}
								?>
								
								
								
                                
                                
                                <?php
								if(isset($erorr) && $erorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$erorr;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
                                <?php
								if(isset($titleerorr) && $titleerorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong>خطا در انجام عملیات : </strong> <?=$titleerorr;?>
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
                                <?php
								if(isset($texterror) && $texterror!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong>خطا در انجام عملیات : </strong> <?=$texterror;?>
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
                    
                        <section class="panel">
                            <header class="panel-heading">
                                ثبت خبر جدید
                         
                            </header>
                            <div class="panel-body">
                            
                            
                                <form role="form" method="post">
                                
                                
                                
                                
                                	<div class="form-group">
                                        <label for="exampleInputEmail1">خبر برای:</label>
                                        <select name="to" style="width:100%" id="to">
                                            <option value="0">دانش آموزان / معلمین</option>
                                        	<option value="1">دانش آموزان</option>
                                            <option value="2">معلمین</option>
                                        </select>
                                    </div>
                                
                                
                                
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">عنوان</label>
                                        <input name="title" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>
                                    
                                    <!--
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">متن خبر</label>
                                        <input name="text" type="text" class="form-control" id="exampleInputEmail1">
                                    </div>
                                    -->
                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">متن خبر</label>
                                        <textarea name="text" class="form-control" id="exampleInputEmail1" style="height:100px;"></textarea>
                                    </div>
                                    
                                   
                                    <br>
                                    
                                    <input type="submit" name="insert-news" class="btn btn-info" value="ثبت خبر">
                                    <button class="btn btn-default" type="reset">پاک کردن فرم</button>
                                </form>

                            </div>
                        </section>
                    </div>
                    
                </div>
				
                
                
                
				
                <div class="row">
                    <div class="col-lg-12">
                        <section class="panel">
                            <header class="panel-heading">
                                
                                لیست اخبار
                         
                            </header>
                            <table class="table table-striped table-advance table-hover">
                                <thead>
                                    <tr>
										<th>#</th>
                                        <th>عنوان</th>
                                        <th class="hidden-phone">متن خبر</th>
                                        <th>خبر برای</th>
										<th>تاریخ / ساعت</th>
                                        <th>عملیات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                
                                <?php
								$i=0;
								$sql = "select * from tbl_news order by 1 desc";
								$query = mysqli_query($con,$sql);
								while($fetch = mysqli_fetch_assoc($query))
								{
									$i++;
									echo "<tr>";
									echo "<td>".$i."</td>";
									echo "<td>".$fetch["title"]."</td>";
									echo "<td>".$fetch["text"]."</td>";
									
									switch($fetch["to"]){
										case 0:
											$messageto="دانش آموزان / معلمین";
											break;
										case 1:
											$messageto="دانش آموزان";
											break;
										case 2:
											$messageto="معلمین";
											break;
										default:
											$messageto="تعریف نشده";
									}
									
									echo "<td>".$messageto."</td>";
									echo "<td>".$fetch["date"]." - ".$fetch["time"]."</td>";
									
									$x=$fetch["id"];
									
									echo "<td>
									
									
									<button class='btn btn-success btn-xs'><i class='icon-ok'></i></button>
									

									
									<a class='btn btn-primary btn-xs' style='color:#fff;' href=news-edit.php?id=".$fetch["id"]."&to=".$fetch["to"]."><i class='icon-pencil'>"." "."ویرایش</i></a>
										
										
									<a class='btn btn-danger btn-xs' style='color:#fff;' OnClick='del($x)'><i class='icon-trash'>"." "."حذف</i></a>
									
									
									</td>";
									echo "</tr>";
								}
								
								?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </div>
                <!-- page end-->
				
				
            </section>
            
			
            <script type="text/javascript">
				function del(id)
				{
					var x=confirm("آیا از حذف خبر اطمینان دارید؟");
					if(x==true)
					{
						window.location.href="news-delete.php?id="+id;
					}
					else
					{
						window.location.href="#";
					}
				}
			</script>
			
            
            
	  </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
