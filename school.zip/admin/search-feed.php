<?php

require_once ("../functions/rep.php");
$records = "";

if(isset($_GET["stu"]) && isset($_GET["keyword"]))
{
  $txtsrch = $_GET["keyword"];
  $query = "SELECT * FROM tbl_students WHERE fullname like '%".$txtsrch."%'";
  $records = mysqli_query($con,$query);
}
else if(isset($_GET["paye"]) && isset($_GET["reshte"]) && isset($_GET["stu"]))
{
  $query = "SELECT * FROM tbl_students WHERE paye = '".$_GET["paye"]."' && reshte = '".$_GET["reshte"]."'";
  $records = mysqli_query($con,$query);
}
else if(isset($_GET["allitem"])&& isset($_GET["stu"]))
{
  $query = "SELECT * FROM tbl_students";
  $records = mysqli_query($con,$query);
}
else if(isset($_GET["tea"]) && isset($_GET["keyword"]))
{
  $txtsrch = $_GET["keyword"];
  $query = "SELECT * FROM tbl_teachers WHERE fullname like '%".$txtsrch."%'";
  $records = mysqli_query($con,$query);
}
else
{
  header("location:index.php");
  exit;
}

$out = array();
$out['raw'] = array();

foreach($records as $record)
{
  $out['raw'][] = $record;
}

echo json_encode($out);
?>