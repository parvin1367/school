<?php

if(isset($_GET['id']))
{
	include "../functions/connection.php";
	$sql = "DELETE FROM `tbl_news` WHERE `tbl_news`.`id` = '".$_GET['id']."'";
	$query = mysqli_query($con,$sql);
	if($query)
	{
		header("location:news-insert.php?deleteok=3645");
		exit;
	}
	else
	{
		header("location:news-insert.php?deleteerror=9442");
		exit;	
	}
}
else
{
	header ("location:index.php");
	exit;
}

?>