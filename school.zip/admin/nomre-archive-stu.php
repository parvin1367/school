<?php


include "../functions/rep.php";

if(isset($_GET["id"]) && isset($_GET["paye"]))
{
	$suname=$_GET["id"];
	$paye=$_GET["paye"];
	
	$sqlstu="select `fullname` from tbl_students where `username`='".$suname."' ";
	$querystu=mysqli_query($con,$sqlstu);
	if(mysqli_num_rows($querystu)>0)
	{
		$fetchstu=mysqli_fetch_assoc($querystu);
		$stufullname=$fetchstu["fullname"];
	}
	else
	{
		$stufullname="دانش آموز یافت نشد";
	}
}
else
{
	header("location:index.php");
	exit;
}

	
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

    <?php
	include "head.php";
	?>
	<link rel="stylesheet" type="text/css" href="print3.css" media="print">
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
      <section id="main-content">
      
      <section class="wrapper">
                <!-- page start-->
                
				
				
                <div class="row">
                    <div class="col-lg-12">
                    

                    
                        <section class="panel">
                        
                        
                            <header class="panel-heading">
                                
                                کارنامه دانش آموز: <?=$stufullname?> - پایه: <?=$paye?>
								
								<div class="panel-body" style="float:left;margin-top:-20px;">
									<a href="?id=<?=$suname?>&paye=<?=$paye?>&print=54" class="btn btn-info "><i class="icon-print"></i> پرینت کارنامه </a>
								</div>
								
								<?php
								if(isset($_GET['print']))
								{
								?>
									<script>
										javascript:window.print();
									</script>
								<?php
								}
								?>
                         
                            </header>
                            <table class="table table-striped table-advance table-hover">
                                <thead>
                                    <tr>
										<th>#</th>
                                        <th>درس</th>
                                        <th>مدرس</th>
                                        <th>عنوان ارزشیابی</th>
										<th>تاریخ</th>
                                        <th>نمره</th>
                                    </tr>
                                </thead>
                                <tbody>
									<?php
									
									$i=0;
									$j=0;
									$mynom=0;
									$mynomre=0;
									$examcount=0;
									$avenomre=0;
									
									$sql="SELECT * FROM tbl_marksdetail INNER JOIN tbl_marks ON tbl_marksdetail.markid=tbl_marks.markid where tbl_marksdetail.suname='".$suname."' && tbl_marks.markpaye='".$paye."' order by `tbl_marks`.`id` desc;";
									$query=mysqli_query($con,$sql);
									while($fetch=mysqli_fetch_assoc($query))
									{
										$x=$fetch["nomre"];
										$i++;
										
										
										//average
										if($x!=0)
										{
											$mynomre=$x;
											$j++;
											$mynom+=$mynomre;
											if($mynom!=0)
											{
												$avenomre=($mynom/$j);
												$examcount=$j;
											}
										}
										else
										{
											$avenomre=0;
											$examcount=0;
										}
										
										
										
										if($x==0)
										{
											$n="<span style='font-size:12px;background-color:black;' class='label label-info'>گزارش نشده</span>";
										}
										else
										{
											switch ($x)
											{
												case ($x<=20 && $x>=17):
													$n="<span style='font-size:12px;background-color:green;' class='label label-success'>".$x."</span>";
													break;
												case ($x>=12 && $x<17):
													$n="<span style='font-size:12px;background-color:blue;' class='label label-warning'>".$x."</span>";
													break;
												case $x>=1 && $x<12:
													$n="<span style='font-size:12px;background-color:red;' class='label label-danger'>".$x."</span>";
													break;
											}

										}
										
										
										$sql2="select `name` from tbl_course where `id`='".$fetch["darsid"]."'";
										$query2=mysqli_query($con,$sql2);
										$fetch2=mysqli_fetch_assoc($query2);
										
										$sql3="select `fullname` from tbl_teachers where `username`='".$fetch["tuname"]."'";
										$query3=mysqli_query($con,$sql3);
										$fetch3=mysqli_fetch_assoc($query3);
									?>
										<tr>
										<td><?=$i?></td>
										<td><?=$fetch2["name"]?></td>
										<td><?=$fetch3["fullname"]?></td>
										<td><?=$fetch["marktitle"]?></td>
										<td><?=$fetch["date"]?></td>
										<td><?=$n?></td>
										</tr>
										
										
									<?php
									}
									?>
									
									<tr style="">
										<td colspan="3" style="background-color:#ddd;text-align:center; width: 50%;font-size:16px; color:red;"><span> تعداد ارزشیابی ثبت شده : </span><b><?=$examcount?></b></td>
										<td colspan="3" style="background-color:#ddd;text-align:center; width: 50%;font-size:16px; color:red;"><span> معدل کل : </span><b><?=round($avenomre,2)?></b></td>
									</tr>
									
                                </tbody>
                            </table>
                        </section>
                        
                        
								
                        
                        
                    </div>
                </div>
                <!-- page end-->
				
				
            </section>
            
            
            
            
	  </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
