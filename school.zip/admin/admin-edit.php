<?php


include "../functions/rep.php";


$sql = "select * from tbl_admin";
$query = mysqli_query($con,$sql);
if(mysqli_num_rows($query)==0)
{
  header("location:index.php");
  exit;
}
$fetch = mysqli_fetch_assoc($query);



if(isset($_POST['edit-admin']))
{
  if($_POST['fname']!="" && $_POST['lname']!="" && $_POST['username']!="" && $_POST['password']!="" && $_POST['password2']!="")
  {

    if($_POST["password"]!=$_POST["password2"])
    {
      $passrep = "کلمات عبور با هم مطابقت ندارند";
    }
    else
    {

      $uppic=$fetch["img"];

      //آپلود عکس
      if($_FILES["file"]["name"]!="")
      {
        if($_FILES["file"]["error"]>0)
        {
          echo "<script>alert('خطای آپلود فایل تصویر')</script>";
        }
        else
        {
          $filename=$_FILES["file"]["name"];
          $filetype=$_FILES["file"]["type"];
          $temp=$_FILES["file"]["tmp_name"];

          $whitelist=array("image/jpeg","image/jpg","image/png","image/gif");
          $myfile=md5($filename.microtime()).substr($filename,-5,5);
          $save_url="../images/admin/";
          $db_url="images/admin/".$myfile;
          if(in_array($filetype,$whitelist))
          {
            if(is_uploaded_file($temp))
            {
              $uppic="";
              $m=move_uploaded_file($temp,$save_url.$myfile);
              if($m)
              {
                $uppic=$db_url;
                echo "<script>alert('موفق در آپلود تصویر')</script>";
              }
              else
              {
                echo "<script>alert('خطای آپلود تصویر')</script>";
              }
            }
          }
          else
          {
            echo "<script>alert('خطای فرمت فایل تصویر')</script>";
          }
        }
      }

      $password = myHashData("sha1",$_POST["password"]);
      $fname = myPrevent($_POST["fname"]);
      $lname = myPrevent($_POST["lname"]);
      $username = myPrevent($_POST["username"]);
      $pass = myPrevent($password);


      $sql="UPDATE `tbl_admin` SET `fname` = '".$fname."', `lname` = '".$lname."' , `username` = '".$username."', `password` = '".$pass."' , `img`='".$uppic."'";


      $query=mysqli_query($con,$sql);
      if($query)
      {
        //$success = "عملیات ویرایش با موفقیت انجام شد.";
        echo "<script>alert('عملیات ویرایش با موفقیت انجام شد. شما از سیستم خارج خواهید شد و مجددا وارد سیستم شوید.');</script>";
        header ("location:admin-logout.php");
        exit;
      }
      else
      {
        $erorr = "خطا در عملیات ویرایش";
      }
    }
  }
  else
  {
    if($_POST['fname'] == "") $fnameerror = "لطفا نام را وارد کنید";
    if($_POST['lname'] == "") $lnameerror = "لطفا نام خانوادگی را وارد کنید";
    if($_POST['username'] == "") $usernameerror = "لطفا نام کاربری را وارد کنید";
    if($_POST['password']=="" || $_POST['password2']=="") $passworderror = "لطفا کلمات عبور را وارد کنید";
  }

}
else
{

}

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>پنل مدیریت : <?php echo $fullname; ?></title>

  <?php
  include "head.php";
  ?>

</head>

<body>

<section id="container" class="">

  <!--header start-->
  <?php include ("header.php"); ?>
  <!--header end-->


  <!--sidebar start-->
  <?php include ("sidebar.php"); ?>
  <!--sidebar end-->


  <!--main content start-->
  <section id="main-content">

    <section class="wrapper">
      <!-- page start-->



      <div class="row">

        <div class="col-lg-6" style="width:100%;">



          <?php
          if(isset($success) && $success!="")
          {
            ?>
            <div class="alert alert-success alert-block fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <h4>
                <i class="icon-ok-sign"></i>
                موفق!
              </h4>
              <p><?=$success;?></p>
            </div>
            <?php
          }
          ?>


          <?php
          if(isset($erorr) && $erorr!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong><?=$erorr;?></strong>

            </div>
            <?php
          }
          ?>




          <?php
          if(isset($passrep) && $passrep!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong><?=$passrep;?></strong>

            </div>
            <?php
          }
          ?>



          <?php
          if(isset($fnameerror) && $fnameerror!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong>خطا در انجام عملیات : </strong> <?=$fnameerror;?>

            </div>
            <?php
          }
          ?>


          <?php
          if(isset($lnameerror) && $lnameerror!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong>خطا در انجام عملیات : </strong> <?=$lnameerror;?>

            </div>
            <?php
          }
          ?>

          <?php
          if(isset($usernameerror) && $usernameerror!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong>خطا در انجام عملیات : </strong> <?=$usernameerror;?>

            </div>
            <?php
          }
          ?>

          <?php
          if(isset($passworderror) && $passworderror!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong>خطا در انجام عملیات : </strong> <?=$passworderror;?>

            </div>
            <?php
          }
          ?>



          <section class="panel">
            <header class="panel-heading">
              ویرایش اطلاعات مدیر

            </header>
            <div class="panel-body">


              <font>* پر کردن فیلد های ستاره دار الزامی می باشد.</font><br>
              <br>



              <form role="form" method="post" enctype="multipart/form-data">


                <div class="form-group">
                  <label for="exampleInputEmail1"><font color="red">*</font>نام</label>
                  <input name="fname" type="text" value="<?php echo $fetch["fname"] ?>" class="form-control" id="exampleInputEmail1">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1"><font color="red">*</font>نام خانوادگی</label>
                  <input name="lname" type="text" value="<?php echo $fetch["lname"] ?>" class="form-control" id="exampleInputEmail1">
                </div>



                <div class="form-group">
                  <label for="exampleInputEmail1"><font color="red">*</font>نام کاربری</label>
                  <input name="username" type="text"  value="<?php echo $fetch["username"] ?>" class="form-control" id="exampleInputEmail1">
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1"><font color="red">*</font>کلمه عبور</label>
                  <input name="password" type="text"  class="form-control" id="exampleInputPassword1"   placeholder="کلمه عبور را تایپ کنید....." >
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1"><font color="red">*</font>تکرار کلمه عبور</label>
                  <input name="password2" type="text"  class="form-control" id="exampleInputPassword1"    placeholder="مجددا کلمه عبور را تایپ کنید....."   >
                </div>


                <div class="form-group">
                  <label for="exampleInputFile">تصویر مدیر</label>
                  <input name="file" type="file" class="form-control" id="bdate" ">
                </div>
                <br>


                <input type="submit" name="edit-admin" class="btn btn-info" value="ویرایش اطلاعات">
                <button class="btn btn-default" type="reset">پاک کردن فرم</button>
              </form>


            </div>
          </section>
        </div>

      </div>








    </section>




  </section>
  <!--main content end-->

</section>


<!-- js placed at the end of the document so the pages load faster -->
<script src="../styles/js/jquery.js"></script>
<script src="../styles/js/jquery-1.8.3.min.js"></script>
<script src="../styles/js/bootstrap.min.js"></script>
<script src="../styles/js/jquery.scrollTo.min.js"></script>
<script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
<script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
<script src="../styles/js/owl.carousel.js" ></script>
<script src="../styles/js/jquery.customSelect.min.js" ></script>

<!--common script for all pages-->
<script src="../styles/js/common-scripts.js"></script>

<!--script for this page-->
<script src="../styles/js/sparkline-chart.js"></script>
<script src="../styles/js/easy-pie-chart.js"></script>

<script>

  //owl carousel

  $(document).ready(function() {
    $("#owl-demo").owlCarousel({
      navigation : true,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem : true

    });
  });

  //custom select box

  $(function(){
    $('select.styled').customSelect();
  });

</script>

</body>
</html>
