<?php

if(isset($_GET['id']))
{
	include "../functions/connection.php";
	$sql = "DELETE FROM `tbl_proweek` WHERE `tbl_proweek`.`id` = '".$_GET['id']."'";
	$query = mysqli_query($con,$sql);
	if($query)
	{
		header("location:proweek-list.php?deleteok=3645");
		exit;
	}
	else
	{
		header("location:proweek-list.php?deleteerror=9442");
		exit;
	}
}
else
{
	header ("location:index.php");
	exit;
}

?>