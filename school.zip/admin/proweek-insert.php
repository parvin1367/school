<?php


include "../functions/rep.php";




if(isset($_POST['insert-proweek']))
{

  $sqlc="select `teacherid` from tbl_course where `id`='".$_POST["course"]."'";
  $queryc=mysqli_query($con,$sqlc);
  if(mysqli_num_rows($queryc)>0)
  {
    $fetchc=mysqli_fetch_assoc($queryc);
    $t=$fetchc["teacherid"];
  }
  else
  {
    $t="-";
  }

  $teacher = $t;
  $paye = myPrevent($_GET["paye"]);
  $reshte = myPrevent($_GET["reshte"]);
  $course = myPrevent($_POST["course"]);
  $day = myPrevent($_POST["day"]);
  $hour = myPrevent($_POST["hour"]);

  $sql="INSERT INTO `tbl_proweek` (`id`, `paye`, `reshte`, `courseid`, `teacherid` ,`day`, `hour`) VALUES (NULL, '".$paye."', '".$reshte."', '".$course."', '".$teacher."' , '".$day."', '".$hour."');";

  $query=mysqli_query($con,$sql);
  if($query)
  {
    $success = "درس با کد ".$course." با موفقیت در برنامه هفتگی ثبت شد";
  }
  else
  {
    $erorr = "خطا در عملیات ثبت";
  }
}
else
{

}

if(isset($_GET["updateok"]))
{
  $editok="ویرایش > موفق";
}
if(isset($_GET["deleteok"]))
{
  $deleteok="حذف > موفق";
}


?>


<!DOCTYPE html>
<html lang="en">
<head>


  <title>پنل مدیریت : <?php echo $fullname; ?></title>

  <?php
  include "head.php";
  ?>

</head>

<body>

<section id="container" class="">

  <!--header start-->
  <?php include ("header.php"); ?>
  <!--header end-->


  <!--sidebar start-->
  <?php include ("sidebar.php"); ?>
  <!--sidebar end-->


  <!--main content start-->
  <section id="main-content">

    <section class="wrapper">
      <!-- page start-->



      <div class="row">

        <div class="col-lg-6" style="width:100%;">



          <?php
          if(isset($success) && $success!="")
          {
            ?>
            <div class="alert alert-success alert-block fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <h4>
                <i class="icon-ok-sign"></i>
                موفق!
              </h4>
              <p><?=$success;?></p>
            </div>
            <?php
          }
          ?>


          <?php
          if(isset($deleteok) && $deleteok!="")
          {
            ?>
            <div class="alert alert-success alert-block fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <h4>
                <i class="icon-ok-sign"></i>
                موفق!
              </h4>
              <p><?=$deleteok;?></p>
            </div>
            <?php
          }
          ?>



          <?php
          if(isset($editok) && $editok!="")
          {
            ?>
            <div class="alert alert-success alert-block fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <h4>
                <i class="icon-ok-sign"></i>
                موفق!
              </h4>
              <p><?=$editok;?></p>
            </div>
            <?php
          }
          ?>





          <?php
          if(isset($erorr) && $erorr!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong><?=$erorr;?></strong>

            </div>
            <?php
          }
          ?>


          <?php
          if(isset($selecterror) && $selecterror!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong><?=$selecterror;?></strong>

            </div>
            <?php
          }
          ?>



          <?php
          if(isset($selerr) && $selerr!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong><?=$selerr;?></strong>

            </div>
            <?php
          }
          ?>




          <section class="panel">
            <header class="panel-heading">

              تنظیم برنامه هفتگی

              <br>

              <div class="panel-body">
                <a href="?paye=7&reshte=عمومی" class="btn btn-shadow btn-danger">پایه هفتم عمومی</a>
                <a href="?paye=8&reshte=عمومی" class="btn btn-shadow btn-warning">پایه هشتم عمومی</a>
                <a href="?paye=9&reshte=عمومی" class="btn btn-shadow btn-success">پایه نهم عمومی</a>


                <div class="btn-group" style="">
                  <button data-toggle="dropdown" class="btn btn-default dropdown-toggle btn-shadow btn-info" type="button">پایه دوم<span class="caret"></span></button>
                  <ul role="menu" class="dropdown-menu">
                    <li><a href="?paye=2&reshte=انسانی">انسانی</a></li>
                    <li><a href="?paye=2&reshte=تجربی">تجربی</a></li>
                    <li><a href="?paye=2&reshte=ریاضی">ریاضی</a></li>
                  </ul>
                </div>



                <div class="btn-group" style="">
                  <button data-toggle="dropdown" class="btn btn-default dropdown-toggle btn-shadow btn-primary" type="button">پایه سوم<span class="caret"></span></button>
                  <ul role="menu" class="dropdown-menu">
                    <li><a href="?paye=3&reshte=انسانی">انسانی</a></li>
                    <li><a href="?paye=3&reshte=تجربی">تجربی</a></li>
                    <li><a href="?paye=3&reshte=ریاضی">ریاضی</a></li>
                  </ul>
                </div>


              </div>

            </header>
            <div class="panel-body">


              <form role="form" method="post">


                <div class="form-group">
                  <label for="exampleInputEmail1">روز:</label>
                  <select name="day" style="width:100%" id="day">
                    <option value="0">شنبه</option>
                    <option value="1">یک شنبه</option>
                    <option value="2">دو شنبه</option>
                    <option value="3">سه شنبه</option>
                    <option value="4">چهار شنبه</option>
                    <option value="5">پنج شنبه</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">ساعت:</label>
                  <select name="hour" style="width:100%" id="hour">
                    <option value="1">ساعت اول</option>
                    <option value="2">ساعت دوم</option>
                    <option value="3">ساعت سوم</option>
                  </select>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">درس:</label>
                  <select name="course" style="width:100%" id="course">
                    <?php

                    $sqlcourse="select * from `tbl_course` where `payeid`='".$_GET["paye"]."' && `reshteid`='".$_GET["reshte"]."'";
                    $querycourse=mysqli_query($con,$sqlcourse);

                    while($fetchcourse=mysqli_fetch_assoc($querycourse))
                    {
                      $sqlteacher="select `fullname`,`username` from tbl_teachers where `username`='".$fetchcourse["teacherid"]."'";
                      $queryteacher=mysqli_query($con,$sqlteacher);
                      if(mysqli_num_rows($queryteacher)>0)
                      {
                        $fetchteacher=mysqli_fetch_assoc($queryteacher);
                        $tname=$fetchteacher["fullname"];
                        $tuname=$fetchteacher["username"];
                      }
                      else
                      {
                        $tname="تعریف نشده";
                        $tuname="-";
                      }
                      ?>
                      <option value="<?php echo $fetchcourse["id"] ?>"><?php echo $fetchcourse["name"] . " - " . $tname ?></option>
                      <?php
                    }
                    ?>
                  </select>
                </div>

                <br>

                <input type="submit" name="insert-proweek" class="btn btn-info" value="ثبت در برنامه">
                <button class="btn btn-default" type="reset">پاک کردن فرم</button>
              </form>

            </div>
          </section>
        </div>

      </div>




    </section>


    <script type="text/javascript">
      function del(id)
      {
        var x=confirm("آیا از حذف درس اطمینان دارید؟");
        if(x==true)
        {
          window.location.href="proweek-delete.php?id="+id;
        }
        else
        {
          window.location.href="#";
        }
      }
    </script>



  </section>
  <!--main content end-->

</section>


<!-- js placed at the end of the document so the pages load faster -->
<script src="../styles/js/jquery.js"></script>
<script src="../styles/js/jquery-1.8.3.min.js"></script>
<script src="../styles/js/bootstrap.min.js"></script>
<script src="../styles/js/jquery.scrollTo.min.js"></script>
<script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
<script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
<script src="../styles/js/owl.carousel.js" ></script>
<script src="../styles/js/jquery.customSelect.min.js" ></script>

<!--common script for all pages-->
<script src="../styles/js/common-scripts.js"></script>

<!--script for this page-->
<script src="../styles/js/sparkline-chart.js"></script>
<script src="../styles/js/easy-pie-chart.js"></script>

<script>

  //owl carousel

  $(document).ready(function() {
    $("#owl-demo").owlCarousel({
      navigation : true,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem : true

    });
  });

  //custom select box

  $(function(){
    $('select.styled').customSelect();
  });

</script>

</body>
</html>
