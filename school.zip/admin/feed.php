<?php

require_once ("../functions/rep.php");

$records = "";

if(isset($_GET["paye"]) && isset($_GET["reshte"]))
{
  $query = "select tbl_marks.markid,tbl_marks.marktitle,tbl_marks.markdetails,tbl_marks.markpaye,tbl_marks.markreshte,tbl_marks.date,tbl_marks.darsid,tbl_teachers.fullname,tbl_course.name
  from tbl_marks inner join tbl_teachers
  on tbl_marks.tuname=tbl_teachers.username inner join tbl_course
  on tbl_marks.darsid=tbl_course.id
  where tbl_marks.markpaye='".$_GET["paye"]."' && tbl_marks.markreshte='".$_GET["reshte"]."'
  order by tbl_marks.id desc";

  $records = mysqli_query($con,$query);
}
else if(isset($_GET["teacher"]))
{
  $query = "select tbl_marks.markid,tbl_marks.marktitle,tbl_marks.markdetails,tbl_marks.markpaye,tbl_marks.markreshte,tbl_marks.date,tbl_marks.darsid,tbl_teachers.fullname,tbl_course.name
  from tbl_marks inner join tbl_teachers
  on tbl_marks.tuname=tbl_teachers.username inner join tbl_course
  on tbl_marks.darsid=tbl_course.id
  where tbl_marks.tuname='".$_GET["teacher"]."'
  order by tbl_marks.id desc";

  $records = mysqli_query($con,$query);
}
else if(isset($_GET["allitem"]))
{
  $query = "select tbl_marks.markid,tbl_marks.marktitle,tbl_marks.markdetails,tbl_marks.markpaye,tbl_marks.markreshte,tbl_marks.date,tbl_marks.darsid,tbl_teachers.fullname,tbl_course.name
  from tbl_marks inner join tbl_teachers
  on tbl_marks.tuname=tbl_teachers.username inner join tbl_course
  on tbl_marks.darsid=tbl_course.id
  order by tbl_marks.id desc";

  $records = mysqli_query($con,$query);
}
else
{
  header("location:index.php");
  exit;
}

$out = array();
//$out['html'] = '';
$out['raw'] = array();

foreach($records as $record)
{
  //$out['html'] .= '<span>' . $record['marktitle'] . '</span>';
  $out['raw'][] = $record;
}

echo json_encode($out);
?>