<?php

include "../functions/rep.php";

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

	<?php
	include "head.php";
	?>
    
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
		<section id="main-content">
            <section class="wrapper">
                <!-- page start-->
                <div class="row">
				
				
				
				
					<div class="col-sm-6" style="width:100%;">
                        <section class="panel">
                            <header class="panel-heading">
                                پیام های ارسال شده برای دانش آموزان
                            </header>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>موضوع</th>
                                        <th>متن</th>
										<th>تاریخ / ساعت</th>
                                        <th>گیرنده</th>
                                    </tr>
                                </thead>
                                <tbody>
								
								<?php
								
								$i=1;
								$sql="SELECT * FROM `tbl_messages_stu` WHERE `from`='".$adminid."' order by `id` desc";
                                $query=mysqli_query($con,$sql);
								while($fetch=mysqli_fetch_assoc($query))
								{
									
									$sqlteacher="select `fullname`,`username` from tbl_students where `username`='".$fetch["to"]."'";
									$queryteacher=mysqli_query($con,$sqlteacher);
									$fetchteacher=mysqli_fetch_assoc($queryteacher);
									
									echo "<tr>";
									echo "<td>".$i++."</td>";
									echo "<td><b><a href='messages-read-stu.php?id=".$fetch["id"]."&tid=".$fetchteacher["username"]."'>".$fetch["title"]."</a></b></td>";
									echo "<td>".substr($fetch["text"],0,75)."....."."</td>";
									echo "<td>".$fetch["date"]." - ".$fetch["time"]."</td>";
									if(mysqli_num_rows($queryteacher)>0)
									{
										echo "<td>".$fetchteacher["fullname"]."</td>";
									}
									else
									{
										echo "-";
									}
									
									echo "</tr>";
								}
								
								?>
								
                                </tbody>
                            </table>
                        </section>
                    </div>
					
					
					
					
				</div>
			</section>
        </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
