<?php

if(isset($_GET['id']))
{
	include "../functions/connection.php";
	$sql = "DELETE FROM `tbl_students` WHERE `tbl_students`.`id` = '".$_GET['id']."'";
	
	$sql2="select * from tbl_students where id='".$_GET["id"]."'";
	$query2=mysqli_query($con,$sql2);
	$fetch=mysqli_fetch_assoc($query2);
	
	$query = mysqli_query($con,$sql);
	if($query)
	{
		//حذف تصویر دانش آموز از پوشه هاست
		unlink($fetch["image"]);
		
		header("location:student-list.php?deleteok=8464");
		exit;
	}
	else
	{
		header("location:student-list.php?deleteerror=5454");
		exit;	
	}
}
else
{
	header ("location:index.php");
	exit;
}

?>