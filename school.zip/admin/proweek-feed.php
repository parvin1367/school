<?php

require_once ("../functions/rep.php");
$records = "";

if(isset($_GET["paye"]) && isset($_GET["reshte"]))
{
  $query = "select tbl_proweek.id,tbl_proweek.paye,tbl_proweek.reshte,tbl_proweek.day,tbl_proweek.hour,tbl_teachers.fullname,tbl_course.name
from tbl_proweek inner join tbl_teachers
on tbl_proweek.teacherid=tbl_teachers.username inner join tbl_course
on tbl_proweek.courseid=tbl_course.id
where tbl_proweek.paye='".$_GET["paye"]."' && tbl_proweek.reshte='".$_GET["reshte"]."'
order by tbl_proweek.day,tbl_proweek.hour asc";
  $records = mysqli_query($con,$query);
}
else if(isset($_GET["teacher"]))
{
  $query = "select tbl_proweek.id,tbl_proweek.paye,tbl_proweek.reshte,tbl_proweek.day,tbl_proweek.hour,tbl_teachers.fullname,tbl_course.name
from tbl_proweek inner join tbl_teachers
on tbl_proweek.teacherid=tbl_teachers.username inner join tbl_course
on tbl_proweek.courseid=tbl_course.id
where tbl_proweek.teacherid='".$_GET["teacher"]."'
order by tbl_proweek.day,tbl_proweek.hour asc";
  $records = mysqli_query($con,$query);
}
else if(isset($_GET["day"]))
{
  $query = "select tbl_proweek.id,tbl_proweek.paye,tbl_proweek.reshte,tbl_proweek.day,tbl_proweek.hour,tbl_teachers.fullname,tbl_course.name
from tbl_proweek inner join tbl_teachers
on tbl_proweek.teacherid=tbl_teachers.username inner join tbl_course
on tbl_proweek.courseid=tbl_course.id
where tbl_proweek.day='".$_GET["day"]."'
order by tbl_proweek.day,tbl_proweek.hour asc";
  $records = mysqli_query($con,$query);
}
else if(isset($_GET["allitem"]))
{
  $query = "select tbl_proweek.id,tbl_proweek.paye,tbl_proweek.reshte,tbl_proweek.day,tbl_proweek.hour,tbl_teachers.fullname,tbl_course.name
from tbl_proweek inner join tbl_teachers
on tbl_proweek.teacherid=tbl_teachers.username inner join tbl_course
on tbl_proweek.courseid=tbl_course.id
order by tbl_proweek.day,tbl_proweek.hour asc";
  $records = mysqli_query($con,$query);
}
else
{
  header("location:index.php");
  exit;
}

$out = array();
$out['raw'] = array();

foreach($records as $record)
{
  $out['raw'][] = $record;
}

echo json_encode($out);
?>