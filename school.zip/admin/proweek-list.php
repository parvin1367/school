<?php


include "../functions/rep.php";


if(isset($_GET["updateok"]))
{
  $editok="ویرایش > موفق";
}
if(isset($_GET["deleteok"]))
{
  $deleteok="حذف > موفق";
}


?>


<!DOCTYPE html>
<html lang="en">
<head>


  <title>پنل مدیریت : <?php echo $fullname; ?></title>

  <?php
  include "head.php";
  ?>

  <link rel="stylesheet" type="text/css" href="print2.css" media="print">

</head>

<body>

<section id="container" class="">

  <!--header start-->
  <?php include ("header.php"); ?>
  <!--header end-->


  <!--sidebar start-->
  <?php include ("sidebar.php"); ?>
  <!--sidebar end-->


  <!--main content start-->
  <section id="main-content">

    <section class="wrapper">
      <!-- page start-->



      <div class="row">

        <div class="col-lg-6" style="width:100%;">



          <?php
          if(isset($success) && $success!="")
          {
            ?>
            <div class="alert alert-success alert-block fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <h4>
                <i class="icon-ok-sign"></i>
                موفق!
              </h4>
              <p><?=$success;?></p>
            </div>
            <?php
          }
          ?>


          <?php
          if(isset($deleteok) && $deleteok!="")
          {
            ?>
            <div class="alert alert-success alert-block fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <h4>
                <i class="icon-ok-sign"></i>
                موفق!
              </h4>
              <p><?=$deleteok;?></p>
            </div>
            <?php
          }
          ?>



          <?php
          if(isset($editok) && $editok!="")
          {
            ?>
            <div class="alert alert-success alert-block fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <h4>
                <i class="icon-ok-sign"></i>
                موفق!
              </h4>
              <p><?=$editok;?></p>
            </div>
            <?php
          }
          ?>





          <?php
          if(isset($erorr) && $erorr!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong><?=$erorr;?></strong>

            </div>
            <?php
          }
          ?>


          <?php
          if(isset($selecterror) && $selecterror!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong><?=$selecterror;?></strong>

            </div>
            <?php
          }
          ?>



          <?php
          if(isset($selerr) && $selerr!="")
          {
            ?>
            <div class="alert alert-block alert-danger fade in">
              <button data-dismiss="alert" class="close close-sm" type="button">
                <i class="icon-remove"></i>
              </button>
              <strong><?=$selerr;?></strong>

            </div>
            <?php
          }
          ?>



        </div>

      </div>





      <div class="row">
        <div class="col-lg-12">
          <section class="panel">
            <header class="panel-heading">

              لیست دروس ثبت شده در برنامه هفتگی


              <a style="margin: 0 20px;"  onclick="printpage()"  class="btn btn-info "><i class="icon-print"></i> پرینت برنامه هفتگی </a>


              <script>
                function printpage()
                {
                  javascript:window.print();
                }
              </script>



              <br>

              <div class="panel-body" style="float:right;">


                <a id="iman" data-all="all" class="btn btn-shadow btn-default">لیست کل</a>
                <a id="iman" data-paye="7" data-reshte="عمومی" class="btn btn-shadow btn-danger">پایه هفتم عمومی</a>
                <a id="iman" data-paye="8" data-reshte="عمومی" class="btn btn-shadow btn-warning">پایه هشتم عمومی</a>
                <a id="iman" data-paye="9" data-reshte="عمومی" class="btn btn-shadow btn-success">پایه نهم عمومی</a>



                <div class="btn-group" style="">
                  <button data-toggle="dropdown" class="btn btn-default dropdown-toggle btn-shadow btn-info" type="button">پایه دوم<span class="caret"></span></button>
                  <ul role="menu" class="dropdown-menu">
                    <li><a id="iman" data-paye="2" data-reshte="انسانی">انسانی</a></li>
                    <li><a id="iman" data-paye="2" data-reshte="تجربی">تجربی</a></li>
                    <li><a id="iman" data-paye="2" data-reshte="ریاضی">ریاضی</a></li>
                  </ul>
                </div>


                <div class="btn-group" style="">
                  <button data-toggle="dropdown" class="btn btn-default dropdown-toggle btn-shadow btn-primary" type="button">پایه سوم<span class="caret"></span></button>
                  <ul role="menu" class="dropdown-menu">
                    <li><a id="iman" data-paye="3" data-reshte="انسانی">انسانی</a></li>
                    <li><a id="iman" data-paye="3" data-reshte="تجربی">تجربی</a></li>
                    <li><a id="iman" data-paye="3" data-reshte="ریاضی">ریاضی</a></li>
                  </ul>
                </div>

              </div>



              <div class="btn-group" style="float:left; margin-top:20px;">
                <button data-toggle="dropdown" class="btn btn-default dropdown-toggle" type="button">مرتب کردن براساس ایام هفته<span class="caret"></span></button>
                <ul role="menu" class="dropdown-menu">
                  <li><a id="iman" data-day="0">شنبه</a></li>
                  <li><a id="iman" data-day="1">یک شنبه</a></li>
                  <li><a id="iman" data-day="2">دو شنبه</a></li>
                  <li><a id="iman" data-day="3">سه شنبه</a></li>
                  <li><a id="iman" data-day="4">چهار شنبه</a></li>
                  <li><a id="iman" data-day="5">پنج شنبه</a></li>
                </ul>
              </div>


              <div class="btn-group" style="float:left; margin-top:20px; margin-left:3px;">
                <button data-toggle="dropdown" class="btn btn-default dropdown-toggle" type="button">مرتب کردن براساس مدرس<span class="caret"></span></button>
                <ul role="menu" class="dropdown-menu">
                  <?php
                  $sql8="select `fullname`,`username` from tbl_teachers order by `lname`";
                  $query8 = mysqli_query($con,$sql8);
                  while($fetch8 = mysqli_fetch_assoc($query8))
                  {
                    ?>
                    <li><a id="iman" data-teacher="<?=$fetch8["username"]?>"><?=$fetch8["fullname"]?></a></li>
                    <?php
                  }
                  ?>
                </ul>
              </div>



            </header>
            <table class="table table-striped table-advance table-hover">
              <thead>
              <tr>
                <th>#</th>
                <th>نام درس</th>
                <th>مدرس</th>
                <th>پایه / رشته</th>
                <th>روز هفته</th>
                <th>ساعت (زنگ)</th>
                <th class="yjsryzfgnyr">عملیات</th>
              </tr>
              </thead>

              <tbody id="htmltbl">
              </tbody>

            </table>
          </section>
        </div>
      </div>
      <!-- page end-->


    </section>


    <script type="text/javascript">
      function del(id)
      {
        var x=confirm("آیا از حذف درس اطمینان دارید؟");
        if(x==true)
        {
          window.location.href="proweek-delete.php?id="+id;
        }
        else
        {
          window.location.href="#";
        }
      }
    </script>



  </section>
  <!--main content end-->

</section>


<!-- js placed at the end of the document so the pages load faster -->
<script src="../styles/js/jquery.js"></script>
<script src="../styles/js/jquery-1.8.3.min.js"></script>
<script src="../styles/js/bootstrap.min.js"></script>
<script src="../styles/js/jquery.scrollTo.min.js"></script>
<script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
<script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
<script src="../styles/js/owl.carousel.js" ></script>
<script src="../styles/js/jquery.customSelect.min.js" ></script>

<!--common script for all pages-->
<script src="../styles/js/common-scripts.js"></script>

<!--script for this page-->
<script src="../styles/js/sparkline-chart.js"></script>
<script src="../styles/js/easy-pie-chart.js"></script>

<script>

  //owl carousel

  $(document).ready(function() {
    $("#owl-demo").owlCarousel({
      navigation : true,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem : true

    });
  });

  //custom select box

  $(function(){
    $('select.styled').customSelect();
  });

</script>



<script>
  $(function(){
    $(document).ready(function()
    {
      var paye =  $(this).data("paye");
      var reshte = $(this).data("reshte");
      var teacher = $(this).data("teacher");
      var day = $(this).data("day");
      var all = $(this).data("all");

      $.ajax(
        'proweek-feed.php',
        {
          type: 'get',
          dataType: 'json',

          data: {
            paye: paye,
            reshte: reshte,
            teacher: teacher,
            day: day,
            allitem: 'all'
          },

          success: function(data)
          {
            ajaxResult(data);
          }//success
        }//ajax object
      );//ajax
    });
  });//function
</script>



<script>
  $(function(){
    $("a[id=iman]").click(function()
    {

      var paye =  $(this).data("paye");
      var reshte = $(this).data("reshte");
      var teacher = $(this).data("teacher");
      var day = $(this).data("day");
      var all = $(this).data("all");

      $.ajax(
        'proweek-feed.php',
        {
          type: 'get',
          dataType: 'json',

          data: {
            paye: paye,
            reshte: reshte,
            teacher: teacher,
            day: day,
            allitem: all
          },

          success: function(data)
          {
            ajaxResult(data);
          }//success
        }//ajax object
      );//ajax
    });
  });//function
</script>



<script>
  function ajaxResult(data)
  {
    var records = data.raw;
    var html = '';
    var co = 0;
    for (var i in records)
    {
      co++;
      var record = records[i];


      var weekday;
      switch(record.day)
      {
        case "0":
          weekday = "شنبه";
          break;
        case "1":
          weekday = "یکشنبه";
          break;
        case "2":
          weekday = "دو شنبه";
          break;
        case "3":
          weekday = "سه شنبه";
          break;
        case "4":
          weekday = "چهار شنبه";
          break;
        case "5":
          weekday = "پنج شنبه";
          break;
      }

      var payereshte;
      switch (record.paye)
      {
        case "2":
          payereshte="<span class='label label-primary label-mini'>"+ "دوم" +" "+ record.reshte + "</span>";
          break;
        case "3":
          payereshte="<span class='label label-info label-mini'>"+ "سوم" +" "+ record.reshte + "</span>";
          break;
        case "7":
          payereshte="<span class='label label-danger'>"+ "هفتم" +" "+ record.reshte + "</span>";
          break;
        case "8":
          payereshte="<span class='label label-warning'>"+ "هشتم" +" "+ record.reshte + "</span>";
          break;
        case "9":
          payereshte="<span class='label label-success'>"+ "نهم" +" "+ record.reshte + "</span>";
          break;
        default:
          payereshte="نا معتبر";
      }

      html +=
        '<tr>' +
        '<td>' + co + '</td>' +
        '<td>' + record.name + '</td>' +
        '<td>' + record.fullname + '</td>' +
        '<td>' + payereshte + '</td>' +
        '<td>' + weekday + '</td>' +
        '<td>' + record.hour + '</td>' +

        '<td>' + "<a class='btn btn-danger btn-xs' style='color:#fff;' OnClick='del("+record.id+")'><i class='icon-trash'>حذف</i></a>" + '</td>' +
        '</tr>';
    }//for
    $("#htmltbl").html(html);
  }
</script>


</body>
</html>
