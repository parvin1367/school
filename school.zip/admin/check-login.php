<?php
session_start();
include '../functions/connection.php';
include '../functions/func.php';
include '../functions/jdf.php';
if(isset($_POST['login']))
{
  if($_POST["captcha"]!= $_SESSION['captcha'])
  {
    header ("location:admin-login.php?cerror=2516");
    exit;
  }
  else
  {
    if(empty($_POST["user"]) || empty($_POST["pass"]))
    {
      header("location:admin-login.php?empty=1568");
      exit;
    }
    else
    {
      $password = myHashData("sha1",$_POST["pass"]);
      $pass = myPrevent($password);
      $user = myPrevent($_POST["user"]);


      $sql = "select * from tbl_admin where username='".$user."' && password='".$pass."'";
      $result = mysqli_query($con,$sql);
      $num = mysqli_num_rows($result);
      if($num > 0)
      {
        $sqlsettings="select * from tbl_settings";
        $querysettings=mysqli_query($con,$sqlsettings);
        $fetchsettings=mysqli_fetch_assoc($querysettings);
        $_SESSION['schooltitle']=$fetchsettings["schooltitle"];
        $_SESSION['background']=$fetchsettings["background"];

        $_SESSION['chklogin'] = 1;
        $rows = mysqli_fetch_assoc($result);
        $_SESSION['adminid'] = $rows['id'];

        $ip=$_SERVER["REMOTE_ADDR"];
        $mydate=jdate('Y/n/j');
        $mytime=jdate('H:i');

        $sqllog="INSERT INTO `tbl_log` (`id`, `username`, `date`, `time`, `ip`) VALUES (NULL, '".$rows['id']."', '".$mydate."', '".$mytime."', '".$ip."');";
        $querylog=mysqli_query($con,$sqllog);

        header ("location:index.php");
        exit;
      }
      else
      {
        header ("location:admin-login.php?error=2456");
        exit;
      }
    }
  }
}
else
{
  header("location:admin-login.php");
  exit;
}

?>