<?php


include "../functions/rep.php";


$sql = "select * from tbl_settings";
$query = mysqli_query($con,$sql);
if(mysqli_num_rows($query)==0)
{
	header("location:index.php");
	return false;
}
$fetch = mysqli_fetch_assoc($query);

	if(isset($_POST['edit-school']))
	{
		if($_POST['title']!="")
		{
			
			$uppic=$fetch["background"];
		
			//آپلود عکس
			if($_FILES["file"]["name"]!="")
			{
				if($_FILES["file"]["error"]>0)
				{
					echo "<script>alert('خطای آپلود فایل تصویر')</script>";
				}
				else
				{
					$filename=$_FILES["file"]["name"];
					$filetype=$_FILES["file"]["type"];
					$temp=$_FILES["file"]["tmp_name"];
					
					$whitelist=array("image/jpeg","image/jpg","image/png","image/gif");
					$myfile=md5($filename.microtime()).substr($filename,-5,5);
					$save_url="../images/";
					$db_url="images/".$myfile;
					if(in_array($filetype,$whitelist))
					{
						if(is_uploaded_file($temp))
						{
							$uppic="";
							$m=move_uploaded_file($temp,$save_url.$myfile);
							if($m)
							{
								$uppic=$db_url;
								echo "<script>alert('موفق در آپلود تصویر')</script>";
							}
							else
							{
								echo "<script>alert('خطای آپلود تصویر')</script>";
							}
						}
					}
					else
					{
						echo "<script>alert('خطای فرمت فایل تصویر')</script>";
					}
				}
			}
			
			$title = myPrevent($_POST["title"]);
      $stusignup = 0;
      if (isset($_POST['student_signup']) && ($_POST['student_signup'] == 'yes' || $_POST['student_signup'] == true)){
        $stusignup = 1;
      }
      //echo "<script>alert('".$stusignup."');</script>";exit;


			$sql="UPDATE `tbl_settings` SET `schooltitle` = '".$title."', `background` = '".$uppic."', `student_signup` = '".$stusignup."' WHERE `tbl_settings`.`id` = 1;";
			
			
			$query=mysqli_query($con,$sql);
			if($query)
			{
				echo "<script>alert('عملیات ویرایش با موفقیت انجام شد. صفحه را رفرش کنید.');</script>";
				header("location:admin-logout.php");
				exit;
			}
			else
			{
				$erorr = "خطا در عملیات ویرایش";
			}
		}
		else
		{
			if($_POST['title'] == "") $fnameerror = "لطفا نام مدرسه را وارد کنید";
		}
		
	}
	else
	{
		
	}
	
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <title>پنل مدیریت : <?php echo $fullname; ?></title>
	
	<?php
	include "head.php";
	?>
	
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
      <section id="main-content">
      
      <section class="wrapper">
                <!-- page start-->
                
				
                
                <div class="row">
                
                    <div class="col-lg-6" style="width:100%;">
                    
                    
                    
                 			   <?php
								if(isset($success) && $success!="")
								{
								?>
                   				 <div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4>
                                        <i class="icon-ok-sign"></i>
                                        موفق!
                                  </h4>
                                    <p><?=$success;?></p>
                                </div>
                                <?php
								}
								?>
                                
                                
                                <?php
								if(isset($erorr) && $erorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$erorr;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
								
								
                                <?php
								if(isset($fnameerror) && $fnameerror!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong>خطا در انجام عملیات : </strong> <?=$fnameerror;?>
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
								
                    
                        <section class="panel">
                            <header class="panel-heading">
                                ویرایش مشخصات مدرسه
                            </header>
                            <div class="panel-body">
                            
                            
							<font>* پر کردن فیلد های ستاره دار الزامی می باشد.</font><br>
							<br>
                            
                                <form role="form" method="post" enctype="multipart/form-data">

                                	<div class="form-group">
                                        <label for="exampleInputEmail1"><font color="red">*</font>نام مدرسه</label>
                                        <input name="title" type="text" value="<?php echo $fetch["schooltitle"] ?>" class="form-control" id="exampleInputEmail1">
                                    </div>

                                
								
                                    <div class="form-group">
                                        <label for="exampleInputFile">نصویر پس زمینه</label>
                                        <input name="file" type="file" class="form-control" id="bdate" ">
                                    </div>
                                    <br>

                                  <div class="form-group">
                                    <label for="studentsignup"><font color="red">*</font>صفحه ثبت نام دانش آموزان
                                      <input name="student_signup" type="checkbox" <?php if($fetch["student_signup"]) { echo "checked"; } ?> class="checkbox" id="studentsignup">
                                    </label>
                                  </div>
									
                                    
                                    <input type="submit" name="edit-school" class="btn btn-info" value="ویرایش اطلاعات">
                                    <button class="btn btn-default" type="reset">پاک کردن فرم</button>
                                </form>
 

                            </div>
                        </section>
                    </div>
                    
                </div>
				
                
                
                
				
                
				
				
            </section>
            
            
            
            
	  </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
