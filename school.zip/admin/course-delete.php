<?php

if(isset($_GET['id']))
{
	include "../functions/connection.php";
	$sql = "DELETE FROM `tbl_course` WHERE `tbl_course`.`id` = '".$_GET['id']."'";
	$query = mysqli_query($con,$sql);
	if($query)
	{
		header("location:course.php?deleteok=9452");
		exit;
	}
	else
	{
		header("location:course.php?deleteerror=9442");
		exit;	
	}
}
else
{
	header ("location:index.php");
	exit;
}

?>