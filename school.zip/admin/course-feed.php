<?php

require_once ("../functions/rep.php");

$records = "";

if(isset($_GET["paye"]) && isset($_GET["reshte"]))
{
  $query = "select tbl_course.id,tbl_course.name,tbl_course.payeid,tbl_course.reshteid,tbl_course.teacherid,tbl_teachers.fullname
from tbl_course inner join tbl_teachers
on tbl_course.teacherid = tbl_teachers.username
where tbl_course.payeid='".$_GET["paye"]."' && tbl_course.reshteid='".$_GET["reshte"]."'";
  $records = mysqli_query($con,$query);
}
else if(isset($_GET["teacher"]))
{
  $query = "select tbl_course.id,tbl_course.name,tbl_course.payeid,tbl_course.reshteid,tbl_course.teacherid,tbl_teachers.fullname
from tbl_course inner join tbl_teachers
on tbl_course.teacherid = tbl_teachers.username
where tbl_course.teacherid='".$_GET["teacher"]."'";
  $records = mysqli_query($con,$query);
}
else if(isset($_GET["allitem"]))
{
  $query = "select tbl_course.id,tbl_course.name,tbl_course.payeid,tbl_course.reshteid,tbl_course.teacherid,tbl_teachers.fullname
from tbl_course inner join tbl_teachers
on tbl_course.teacherid = tbl_teachers.username";
  $records = mysqli_query($con,$query);
}
else
{
  header("location:index.php");
  exit;
}

$out = array();
$out['raw'] = array();

foreach($records as $record)
{
  $out['raw'][] = $record;
}

echo json_encode($out);
?>