<?php

if(isset($_GET["id"]) && isset($_GET["courseid"]) && isset($_GET["paye"]) && isset($_GET["reshte"]))
{
	include("../functions/rep.php");
	
	
	$sqlcourse="select * from tbl_course where id='".$_GET["courseid"]."'";
	$querycourse=mysqli_query($con,$sqlcourse);
	$fetchcourse=mysqli_fetch_assoc($querycourse);
	$dname=$fetchcourse["name"];
	
}
else
{
	header("location:index.php");
	exit;
}

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>

<link rel="stylesheet" type="text/css" href="print.css" media="print">
<style type="text/css">

@font-face {
    font-family: iman;
    src: url(../styles/fonts/Yekan-modified.ttf);
}


*{
	font-family:iman;
	font-weight:normal !important;
}

h1{
	font-size:20px;
}
h2{
	font-size:17px;
}

.in{
}

table input{
	width:98%;
	text-align: center;
}

tr:nth-child(even){
	background-color:#eee;
}

td{
	padding:0 8px;
}

</style>

</head>

<body dir="rtl">
<center>


<br>
<?php
	echo "<h1>نمرات درس ".$dname." <span>دانش آموزان پایه ".$_GET["paye"]." ".$_GET["reshte"]."</span></h1>";
		
	$sqlmark="select * from `tbl_marks` where `markid`='".$_GET["id"]."'";
	$querymark=mysqli_query($con,$sqlmark);
	if(mysqli_num_rows($querymark)>0)
	{
		$tname="";
		$fetchmark=mysqli_fetch_assoc($querymark);
		$sqlteacher="select `fullname` from `tbl_teachers` where `username`='".$fetchmark["tuname"]."'";
		$queryteacher=mysqli_query($con,$sqlteacher);
		if(mysqli_num_rows($queryteacher)>0)
		{
			$fetchteacher=mysqli_fetch_assoc($queryteacher);
			$tname=$fetchteacher["fullname"];
		}
		$examnotes=$fetchmark["markdetails"];
		echo "<h2>مدرس ".$tname." : ".$fetchmark["marktitle"]."</h2>";
	}

?>

	
    <div class="result"></div>
    <form method="post">
  <table width="550" border="0" align="center">
    <tr>
	  <td  bgcolor="#00CCFF" style="text-align: center; font-weight: bold;">#</td>
      <td  bgcolor="#00CCFF" style="text-align: center; font-weight: bold;">نام و نام خانوادگی</td>
      <td  bgcolor="#00CCFF" style="text-align: center; font-weight: bold;">نمره</td>
    </tr>
    
	<?php
	$i=0;
	$markid=$_GET['id'];
	$sqlstudent="select * from `tbl_students` where `paye`='".$_GET["paye"]."' && `reshte`='".$_GET["reshte"]."' order by `lname`";
	$querystudent=mysqli_query($con,$sqlstudent);
	while($fetchstudent=mysqli_fetch_assoc($querystudent))
	{
		$i++;
		?>
        
		<tr>
        <td><?php echo $i; ?></td>
        <td><?php echo $fetchstudent["fullname"]; ?></td>
        
        <?php
		$sqlmrk="select * from `tbl_marksdetail` where `markid`='".$markid."' && `suname`='".$fetchstudent['username']."' ";
		$querymrk=mysqli_query($con,$sqlmrk);
		while($fetchmrk=mysqli_fetch_assoc($querymrk))
		{
	?>
            
            <td><?php echo "<input type='text' name='qnomre_$i' class='qnomre_$i' value='".$fetchmrk['nomre']."'>" ?></td>
            </tr>
            <td><?php echo "<input type='hidden' name='idmrk_$i' class='idmrk_$i' value='".$fetchmrk["id"]."'>" ?></td>
            <td><?php echo "<input type='hidden' name='qmarkid_$i' class='qmarkid_$i' value='$markid'>" ?></td>
            <td><?php echo "<input type='hidden' name='quname_$i' class='quname_$i' value='".$fetchstudent['username']."'>" ?></td>
        
     
	<?php
		}//while stu
	}//while students
	
	echo "</table>";
	
	echo "<p>توضیحات ارزشیابی: ".$examnotes."</p>";
	
	echo "<input type='submit' class='no-print' name='print' value='پرینت لیست'>&nbsp;";
	//echo "<input type='submit' class='in' name='in' value='ویرایش نمرات دانش آموزان'>&nbsp;";
	echo "<input type='submit' class='no-print' name='courselist' value='بازگشت به آرشیو ارزشیابی'>";
	
	
	
	$count=$i;
	
	if(isset($_POST['in']))
	{
		for($x=1;$x<=$count;$x++)
		{
			$dhkfh="UPDATE `tbl_marksdetail` SET `nomre` = '".$_POST["qnomre_".$x]."' WHERE `tbl_marksdetail`.`id` = '".$_POST["idmrk_".$x]."';";
			$hjfn=mysqli_query($con,$dhkfh);
		}
		if($hjfn)
		{
			//echo "<br><br><font color='green'>نمرات دانش آموزان با موفقیت ویرایش گردید.</font>";
			header("location:nomre-archive.php?editsuccess=5456");
			exit;
		}
		else
		{
			echo "<br><br><font color='red'>خطا در عملیات ویرایش نمرات</font>";
		}
	}
	else if(isset($_POST['courselist']))
	{
		header("location:nomre-archive.php");
		exit;
	}
	else if(isset($_POST['print']))
	{
	?>
		<script>
			javascript:window.print();
		</script>
	<?php
	}
  
  ?>
  </form>
</center>
</body>
</html>