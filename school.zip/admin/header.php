<?php

	$adminid = $_SESSION['adminid'];
	$sql = "select * from tbl_admin where id='".$adminid."'";
	$result = mysqli_query($con,$sql);
	$rows = mysqli_fetch_assoc($result);
	
	$fname = $rows['fname'];
	$lname = $rows['lname'];
	$avatar = $rows['img'];
	$fullname = $fname . " " . $lname;

?>







<header class="header white-bg" style="top:0; min-height:65px; line-height:45px;">
            <div class="sidebar-toggle-box">
                <div data-original-title="Toggle Navigation" data-placement="right" class="icon-reorder tooltips"></div>
            </div>
            
            
            
            
            
            
            
            
            <!--logo start-->
            <a href="#" class="logo">دبیرستان <span><?php echo $_SESSION['schooltitle']; ?></span></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">
                    
					
					
					
					<?php
						$sqlpolls="select * from tbl_polls where `state`='1' order by `id` desc limit 0,5";
						$querypolls=mysqli_query($con,$sqlpolls);
						$countpolls=mysqli_num_rows($querypolls);
					?>
					
					
					<!-- settings start -->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="icon-tasks"></i>
                            <span class="badge bg-success">
							<?php
							if($countpolls>0)
								echo $countpolls; 
							?></span>
                        </a>
                        <ul class="dropdown-menu extended tasks-bar">
                            <div class="notify-arrow notify-arrow-green"></div> 
							<li>
							<?php
							if($countpolls==0)
							{
							?>
                                <p class="green">شما نظر یا پیشنهاد جدیدی ندارید</p>
							<?php
							}
							else
							{
							?>
								<p class="green">شما <?php echo $countpolls; ?> نظر یا پیشنهاد دارید </p>
							<?php
							}
							?>
                            </li>
                            
							<?php
							while($fetchpolls=mysqli_fetch_assoc($querypolls))
							{
							?>
							<li>
                                <a href="polls-read.php?id=<?php echo $fetchpolls["id"]; ?>&flag=1">
                                    <div class="task-info">
                                        <div class="desc"><?php echo substr($fetchpolls["title"],0,40) ?>...</div>
                                        <div class="percent"><?php echo $fetchpolls["date"] ?></div>
                                    </div>
                                </a>
                            </li>
							<?php
							}
							?>
                            
                            <li class="external">
                                <a href="polls-list.php">مشاهده همه نظرات و پیشنهادات</a>
                            </li>
                        </ul>
                    </li>
                    <!-- settings end -->
                    
                    
                    
					
					
					<?php
						$msg=0;
						$sqlmsg="select * from tbl_messages where `to`='1' AND `state`='1'";
						$querymsg=mysqli_query($con,$sqlmsg);
						$countmsg=mysqli_num_rows($querymsg);
						$sqlmsg2="select * from tbl_messages_stu where `to`='1' AND `state`='1'";
						$querymsg2=mysqli_query($con,$sqlmsg2);
						$countmsg2=mysqli_num_rows($querymsg2);
						if($countmsg>0 || $countmsg2>0)
						{
							$msg=$countmsg+$countmsg2;
						}
					?>
					
					
                    <!-- inbox dropdown start-->
                    <li id="header_inbox_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="icon-envelope-alt"></i>
                            <span class="badge bg-important">
							<?php
							if($msg>0)
								echo $msg; 
							?>
							</span>
                        </a>
                        <ul class="dropdown-menu extended inbox">
                            <div class="notify-arrow notify-arrow-red"></div>
                            <li>
							<?php
							if($msg==0)
							{
							?>
                                <p class="red">شما پیام جدیدی ندارید</p>
							<?php
							}
							else
							{
							?>
								<p class="red">شما <?php echo $msg; ?> پیام جدید دارید</p>
							<?php
							}
							?>
                            </li>
							
							<?php
							if($countmsg>0)
							{
							?>
                            <li>
                                <a href="teacher-recived-messages.php">
                                    <span class="subject">
                                    <span class="from">دریافتی از معلمان</span>
                                    <span class="time"><?php echo $countmsg ?></span>
                                    </span>
                                    <span class="message">
                                       مشاهده پیام ها
                                    </span>
                                </a>
                            </li>
							<?php
							}
							?>
							
							<?php
							if($countmsg2>0)
							{
							?>
                            <li>
                                <a href="student-recived-messages.php">
                                    <span class="subject">
                                    <span class="from">دریافتی از دانش آموزان</span>
                                    <span class="time"><?php echo $countmsg2 ?></span>
                                    </span>
                                    <span class="message">
                                       مشاهده پیام ها
                                    </span>
                                </a>
                            </li>
							<?php
							}
							?>
                        </ul>
                    </li>
                    <!-- inbox dropdown end -->
                    
					
					
					
					<!-- notification dropdown start
                    <li id="header_notification_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">

                            <i class="icon-bell-alt"></i>
                            <span class="badge bg-warning">7</span>
                        </a>
                        <ul class="dropdown-menu extended notification">
                            <div class="notify-arrow notify-arrow-yellow"></div>
                            <li>
                                <p class="yellow">شما 7 اعلام جدید دارید</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-danger"><i class="icon-bolt"></i></span>
                                    سرور شماره 3 توقف کرده
                                    <span class="small italic">34 دقیقه قبل</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-warning"><i class="icon-bell"></i></span>
                                    سرور شماره 4 بارگزاری نمی شود
                                    <span class="small italic">1 ساعت قبل</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-danger"><i class="icon-bolt"></i></span>
                                    پنل مدیریت 24% پیشرفت داشته است
                                    <span class="small italic">4 ساعت قبل</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-success"><i class="icon-plus"></i></span>
                                    ثبت نام کاربر جدید
                                    <span class="small italic">همین حالا</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-info"><i class="icon-bullhorn"></i></span>
                                    برنامه پیام خطا دارد
                                    <span class="small italic">10 دقیقه قبل</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">نمایش تمامی اعلام ها</a>
                            </li>
                        </ul>
                    </li>
                     notification dropdown end -->
					
					
					
					
                </ul>
                <!--  notification end -->
            </div>
            
            
            
            
            
            
            <div class="top-nav ">
                <!--search & user info start-->
                <ul class="nav pull-right top-menu">
                    <li>
                        <input type="text" class="form-control search" placeholder="Search">
                    </li>
                    <!-- user login dropdown start-->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <img alt="" style="width:40px;height:50px;" src=<?="../".$avatar;?>>
                            <span class="username"><?php echo $fullname; ?></span>
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu extended logout" style="">
                            <div class="log-arrow-up"></div>
                            <li style="width:33% !important;" ><a href="info.php"><i class="icon-bell-alt"></i> آمار و اطلاعات</a></li>
                            <li style="width:33% !important;" ><a href="admin-edit.php" ><i class=" icon-suitcase"></i>ویرایش اطلاعات</a></li>
                            <li style="width:33% !important;" ><a href="settings.php"><i class="icon-cog"></i> تنظیمات</a></li>

                            <li><a href="admin-logout.php"><i class="icon-key"></i> خروج</a></li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->
                </ul>
                <!--search & user info end-->
            </div>
            <!-- End Top nav -->
            
            
            
            
            
        </header>