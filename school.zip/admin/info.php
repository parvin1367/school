<?php

include "../functions/rep.php";

$sqlx="select * from tbl_admin where `id`='1'";
$queryx=mysqli_query($con,$sqlx);
$fetchx=mysqli_fetch_assoc($queryx);

?>


<!DOCTYPE html>
<html lang="en">
<head>


  <title>پنل مدیریت : <?php echo $fullname; ?></title>

  <?php
  include "head.php";
  ?>

</head>

<body>

<section id="container" class="">

  <!--header start-->
  <?php include ("header.php"); ?>
  <!--header end-->


  <!--sidebar start-->
  <?php include ("sidebar.php"); ?>
  <!--sidebar end-->







  <!--main content start-->
  <section id="main-content">
    <section class="wrapper">
      <!-- page start-->
      <div class="row">




        <aside class="profile-nav col-lg-3">
          <section class="panel">
            <div class="user-heading round">
              <a href="#">
                <img alt="" src=<?="../".$fetchx["img"];?>>
              </a>
              <h1><?php echo $fetchx["fname"]." ".$fetchx["lname"] ; ?></h1>
              <p><?=$fetchx["username"]?></p>
            </div>

          </section>
        </aside>


        <aside class="profile-info col-lg-9">



          <?php
          $sqlip="select * from tbl_log where `username`='1' order by `id` desc limit 0,12";
          $queryip=mysqli_query($con,$sqlip);

          $sqlip2="select * from tbl_log where `username`='1'";
          $queryip2=mysqli_query($con,$sqlip2);
          $cnt=mysqli_num_rows($queryip2);
          ?>

          <section class="panel">
            <header class="panel-heading">
              آمار آخرین ورود به سیستم

              <?php
              if($cnt>0)
              {
                ?>
                <b style="folat:left;display:block;background-color:#ddd;text-align:center;padding:3px;margin:3px 0px;border-radius:5px;">تعداد کل ورود: <?=$cnt?></b>
                <?php
              }
              ?>

            </header>
            <table class="table table-hover">
              <thead>
              <tr>
                <th>#</th>
                <th>آی پی</th>
                <th>تاریخ</th>
                <th>ساعت</th>
              </tr>
              </thead>
              <tbody>

              <?php
              if(mysqli_num_rows($queryip)>0)
              {
                $i=0;
                while($fetchip=mysqli_fetch_assoc($queryip))
                {
                  $i++;
                  ?>
                  <tr>
                    <td><?=$i?></td>
                    <td><?=$fetchip["ip"]?></td>
                    <td><?=$fetchip["date"]?></td>
                    <td><?=$fetchip["time"]?></td>
                  </tr>
                  <?php
                }
              }
              ?>

              </tbody>
            </table>
          </section>






        </aside>
      </div>

      <!-- page end-->
    </section>
  </section>
  <!--main content end-->

</section>


<!-- js placed at the end of the document so the pages load faster -->
<script src="../styles/js/jquery.js"></script>
<script src="../styles/js/jquery-1.8.3.min.js"></script>
<script src="../styles/js/bootstrap.min.js"></script>
<script src="../styles/js/jquery.scrollTo.min.js"></script>
<script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
<script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
<script src="../styles/js/owl.carousel.js" ></script>
<script src="../styles/js/jquery.customSelect.min.js" ></script>

<!--common script for all pages-->
<script src="../styles/js/common-scripts.js"></script>

<!--script for this page-->
<script src="../styles/js/sparkline-chart.js"></script>
<script src="../styles/js/easy-pie-chart.js"></script>

<script>

  //owl carousel

  $(document).ready(function() {
    $("#owl-demo").owlCarousel({
      navigation : true,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem : true

    });
  });

  //custom select box

  $(function(){
    $('select.styled').customSelect();
  });

</script>

</body>
</html>
