<?php

include "teacher-rep.php";

if(isset($_GET["id"]))
{
	if(isset($_GET["flag"]) && $_GET["flag"]==1)
	{
		$sqlupdt="UPDATE `tbl_messages_tea` SET `state` = '0' WHERE `tbl_messages_tea`.`id` = '".$_GET["id"]."';";
		$queryupdt=mysqli_query($con,$sqlupdt);	
	}
	
	//ارسال پاسخ برای مدیر
	if(isset($_POST['send-message']))
	{
		if($_POST['title']!="" && $_POST['text']!="")
		{
			
			$to=$_GET['stuid'];
			$from=$username2;
			$title = myPrevent($_POST["title"]);
			$text = myPrevent($_POST["text"]);

			$sql="INSERT INTO `tbl_messages_tea` (`id`, `from` , `to`, `title`, `text`, `date`,`time`,`state`) VALUES (NULL, '".$from."' , '".$to."', '".$title."', '".$text."' ,'".$mydate."','".$mytime."','1')";

			$query=mysqli_query($con,$sql);
			if($query)
			{
				$success = "پیام شما با موفقیت برای دانش آموز ارسال شد.";
			}
			else
			{
				$erorr = "خطا در ارسال پیام";
			}
			
				
		}
		else
		{
			if($_POST['text'] == "") $texterror = "لطفا متن پیام را وارد کنید";
		}
	}
	else
	{
		//header ("location:index.php");
	}
	
}
else
{
	header("location:index.php");
	exit;
}

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

	<?php
	include "head.php";
	?>
    
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
		<section id="main-content">
            <section class="wrapper">
                <!-- page start-->
                <div class="row">
				
				<?php
					$sql="select * from tbl_messages_tea where id='".$_GET["id"]."'";
					$query=mysqli_query($con,$sql);
					$fetch=mysqli_fetch_assoc($query);
					
				?>
				
				
					<div class="col-lg-6" style="width:99%;margin-top:40px;">
					
					
					
								<?php
								if(isset($success) && $success!="")
								{
								?>
                   				 <div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4>
                                        <i class="icon-ok-sign"></i>
                                        موفق!
                                  </h4>
                                    <p><?=$success;?></p>
                                </div>
                                <?php
								}
								?>
                                
                                
                                <?php
								if(isset($erorr) && $erorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$erorr;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
                                
								
                                
                                <?php
								if(isset($texterror) && $texterror!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong>خطا در انجام عملیات : </strong> <?=$texterror;?>
                             
                                </div>
                                <?php
								}
								?>
					
					
                        <section class="panel">
                            <header class="panel-heading">
                                
								<b>
								<?php
								if(isset($_GET["flag"]))
								{
                  $studentName = " دانش آموز ";
                  if(isset($_GET['stuid'])){
                    $studentnamesql = "SELECT fullname FROM tbl_students WHERE username='".$_GET['stuid']."'";
                    $studentnamequery=mysqli_query($con,$studentnamesql);
                    $studentnamefetch=mysqli_fetch_assoc($studentnamequery);
                    $studentName .= $studentnamefetch['fullname'];
                  }
									echo "<font color='red'>پیام از طرف ".$studentName.": </font>";
								}
								?>
								</b><?php echo $fetch["title"]; ?>
								<?php $titlemsg=$fetch["title"]; ?>
                         
                            </header>
                            <div class="panel-body profile-activity">
                                <h5 class="pull-right"></h5>
                                <div class="activity blue">
                                    <span>
                                        <i class="icon-bullhorn"></i>
                                    </span>
                                    <div class="activity-desk">
                                        <div class="panel">
                                            <div class="panel-body">
                                                <div class="arrow"></div>
                                                <i class=" icon-time"></i>
                                                <h4><b><?php echo $fetch["date"]." - ".$fetch["time"]; ?></b></h4>
                                                <p><?php echo $fetch["text"]; ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

								
								<?php
								if(isset($_GET["flag"]))
								{
								?>
									<br>
									<h5 class="pull-right"><b>جواب دادن به پیام</b></h5>
									<div class="chat-form">
										<form method="post">
											<div class="input-cont ">
												<input type="text" name="text" class="form-control col-lg-12" placeholder="پاسخ خود را تایپ کنید.....">
												<input type="hidden" name="title" value="پاسخ پیام: <?=$titlemsg?>">
											</div>
											<div class="form-group">
												<div class="pull-right chat-features">
													<input class="btn btn-danger" type="submit" name="send-message" value="ارسال پاسخ">
												</div>
											</div>
										</form>
									</div>
								<?php
								}
								?>
								
								

                            </div>
                        </section>
                    </div>
					
					
					
					
				</div>
			</section>
        </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
