<?php

if(isset($_GET["markid"]) && isset($_GET["courseid"]) && isset($_GET["paye"]) && isset($_GET["reshte"]))
{
	include("teacher-rep.php");
	
	
	$sqlcourse="select * from tbl_course where id='".$_GET["courseid"]."'";
	$querycourse=mysqli_query($con,$sqlcourse);
	$fetchcourse=mysqli_fetch_assoc($querycourse);
	$dname=$fetchcourse["name"];
	
}
else
{
	header("location:index.php");
	exit;
}

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>

<style type="text/css">

@font-face {
    font-family: iman;
    src: url(../styles/fonts/Yekan-modified.ttf);
}


*{
	font-family:iman;
}

table input{
	width:98%;
	text-align: center;
}

tr:nth-child(even){
	background-color:#eee;
}

td{
	padding:0 8px;
}


</style>

</head>

<body dir="rtl">
<center>


<br>
<?php
	echo "<h1>ثبت نمرات درس  ".$dname."</h1>";
	echo "<h2>دانش آموزان پایه ".$_GET["paye"]." ".$_GET["reshte"]."</h2>";

?>

	
    <div class="result"></div>
    <form method="post">
  <table width="550" border="0" align="center">
    <tr>
	  <td  bgcolor="#00CCFF" style="text-align: center; font-weight: bold;">#</td>
      <td  bgcolor="#00CCFF" style="text-align: center; font-weight: bold;">نام و نام خانوادگی</td>
      <td  bgcolor="#00CCFF" style="text-align: center; font-weight: bold;">نمره</td>
    </tr>
    
	<?php
	$i=0;
	$markid=$_GET['markid'];
	$sqlstudent="select * from tbl_students where `paye`='".$_GET["paye"]."' && `reshte`='".$_GET["reshte"]."' order by `lname`";
	$querystudent=mysqli_query($con,$sqlstudent);
	while($fetchstudent=mysqli_fetch_assoc($querystudent))
	{
		$i++;
	?>
		<tr>
		<td><?php echo $i; ?></td>
		<td><?php echo $fetchstudent["fullname"]; ?></td>
		<td><?php echo "<input type='text' name='qnomre_$i' class='qnomre_$i'>" ?></td>
        </tr>
        <td><?php echo "<input type='hidden' name='qmarkid_$i' class='qmarkid_$i' value='$markid'>" ?></td>
		<td><?php echo "<input type='hidden' name='quname_$i' class='quname_$i' value='".$fetchstudent['username']."'>" ?></td>
        
        
		
	
	<?php
	}
	
	echo "</table>";
	
	echo "<br>";
	echo "<input type='submit' class='in' name='in' value='ثبت نمرات دانش آموزان'>&nbsp;";
	echo "<input type='submit' class='courselist' name='courselist' value='بازگشت به لیست دروس'>";
	
	$count=$i;
	
	if(isset($_POST['in']))
	{
		for($x=1;$x<=$count;$x++)
		{
			if($_POST["qnomre_".$x]>20 || $_POST["qnomre_".$x]<0)
			{
				echo "<br><br><font color='red'> نمره ردیف ".$x." به دلیل عدم صحیح بودن در بانک اطلاعاتی صفر در نظر گرفته شد : ".$_POST["qnomre_".$x]."</font>";
				echo "<br>شما می توانید از قسمت لیست دانش آموزان آخرین نمره دانش آموزان را تصحیح کنید<font color='red'></font>";
				$_POST["qnomre_".$x]=0;
				$dhkfh="INSERT INTO `tbl_marksdetail` (`id`, `markid`, `suname`, `nomre`) VALUES (NULL, '".$_POST["qmarkid_".$x]."', '".$_POST["quname_".$x]."' , '".$_POST["qnomre_".$x]."');";
				$hjfn=mysqli_query($con,$dhkfh);
			}
			else
			{
				$dhkfh="INSERT INTO `tbl_marksdetail` (`id`, `markid`, `suname`, `nomre`) VALUES (NULL, '".$_POST["qmarkid_".$x]."', '".$_POST["quname_".$x]."' , '".$_POST["qnomre_".$x]."');";
				$hjfn=mysqli_query($con,$dhkfh);
			}
		}
		if($hjfn)
		{
			echo "<br><br><font color='green'>نمرات دانش آموزان با موفقیت در سیستم ثبت گردید.</font>";
		}
		else
		{
			echo "<br><br><font color='red'>خطا در عملیات ثبت نمرات</font>";
		}
	}
	else if(isset($_POST['courselist']))
	{
		header("location:course-list.php");
		exit;
	}
  
  ?>
  </form>
</center>
</body>
</html>