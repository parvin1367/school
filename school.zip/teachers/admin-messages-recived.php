<?php

include "teacher-rep.php";

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

	<?php
	include "head.php";
	?>
    
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
		<section id="main-content">
            <section class="wrapper">
                <!-- page start-->
                <div class="row">
				
				
				
				
					<div class="col-sm-6" style="width:100%;">
                        <section class="panel">
                            <header class="panel-heading">
                                پیام های دریافتی از مدیر
                            </header>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>موضوع</th>
                                        <th>مختصری از متن پیام</th>
										<th>تاریخ / ساعت</th>
										<th>وضعیت</th>
                                    </tr>
                                </thead>
                                <tbody>
								
								<?php
								
								$i=1;
								$sql="SELECT * FROM `tbl_messages` WHERE `to`='".$username2."' order by `id` desc";
                                $query=mysqli_query($con,$sql);
								while($fetch=mysqli_fetch_assoc($query))
								{
									$msgid=$fetch["id"];
									$flag="";
									
									if($fetch["state"]==1)
									{
										$msgstate = "<span class='label label-danger label-mini'>خوانده نشده</span>";
										$flag=1;
									}
									else
									{
										$msgstate = "<span class='label label-primary label-mini'>خوانده شده</span>";
										$flag=0;
									}
									
									
									echo "<tr>";
									echo "<td>".$i++."</td>";
									echo "<td><b><a href='messages-read.php?id=".$msgid."&flag=".$flag."'>".$fetch["title"]."</a></b></td>";
									echo "<td>".substr($fetch["text"],0,75)."....."."</td>";
									echo "<td>".$fetch["date"]." - ".$fetch["time"]."</td>";
									//echo "<td>".$fetch["from"]."</td>";
									//echo "<td>مدیر</td>";
									echo "<td>".$msgstate."</td>";
									echo "</tr>";
								}
								?>
								
								
                                </tbody>
                            </table>
                        </section>
                    </div>
					
					
					
					
				</div>
			</section>
        </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
