<?php


include "teacher-rep.php";

if(isset($_GET["editsuccess"]))
{
	$editsuccess="نمرات دانش آموزان با موفقیت ویرایش گردید.";	
}
	
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

    <?php
	include "head.php";
	?>
	
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
      <section id="main-content">
      
      <section class="wrapper">
                <!-- page start-->
                
				
				
                <div class="row">
                    <div class="col-lg-12">
                    
                    
                   				<?php
								if(isset($editsuccess) && $editsuccess!="")
								{
								?>
                   				 <div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4>
                                        <i class="icon-ok-sign"></i>
                                        موفق!
                                  </h4>
                                    <p><?=$editsuccess;?></p>
                                </div>
                                <?php
								}
								?>
                    
                        <section class="panel">
                        
                        
                            <header class="panel-heading">
                                
                                آرشیو ارزشیابی
                         
                            </header>
                            <table class="table table-striped table-advance table-hover">
                                <thead>
                                    <tr>
										<th>#</th>
                                        <th>عنوان ارزشیابی</th>
                                        <th>توضیحات</th>
                                        <th>درس</th>
                                        <th>پایه / رشته</th>
                                        <th>تاریخ</th>
                                        <th>عملیات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                
                                <?php
								
									//$join="SELECT `tbl_marks`.`marktitle` FROM `tbl_marks` INNER JOIN `tbl_marksdetail` ON `tbl_marks`.`id`=`tbl_marksdetail`.`markid` where `tbl_marks`.`tuname`='".$username2."'";
									$i=0;
									$sql = "select * from `tbl_marks` where `tuname`='".$username2."' order by `id` desc";
									$query = mysqli_query($con,$sql);
									while($fetch = mysqli_fetch_assoc($query))
									{
										$i++;
										$sqlcourse="select * from tbl_course where id='".$fetch["darsid"]."'";
										$querycourse=mysqli_query($con,$sqlcourse);
										if(mysqli_num_rows($querycourse)>0)
										{
											$fetchcourse=mysqli_fetch_assoc($querycourse);
											$dname=$fetchcourse["name"];
										}
										else
											$dname="درس یافت نشد";
										
										
										echo "<tr>";
										echo "<td>".$i."</td>";
										echo "<td>".$fetch["marktitle"]."</td>";
										echo "<td>".$fetch["markdetails"]."</td>";
										echo "<td>".$dname."</td>";
										echo "<td>".$fetch["markpaye"]." - ".$fetch["markreshte"]."</td>";
										echo "<td>".$fetch["date"]."</td>";
										
										echo "<td>

										<a class='btn btn-success btn-xs' style='color:#fff;' href=nomre-edit.php?id=".$fetch["markid"]."&courseid=".$fetch["darsid"]."&paye=".$fetch["markpaye"]."&reshte=".$fetch["markreshte"]."><i class='icon-pencil'>"." "."ویرایش نمرات ارزشیابی</i></a>
										<a class='btn btn-primary btn-xs' style='color:#fff;' href=nomre-print.php?id=".$fetch["markid"]."&courseid=".$fetch["darsid"]."&paye=".$fetch["markpaye"]."&reshte=".$fetch["markreshte"]."><i class='icon-print'>"." "."پرینت نمرات</i></a>
	
										
											</td>";
											
										echo "</tr>";
									}
								
								
								?>
                                </tbody>
                            </table>
                        </section>
                        
                        
								
                        
                        
                    </div>
                </div>
                <!-- page end-->
				
				
            </section>
            
            
            
            
	  </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
