<?php


session_start();
include '../functions/connection.php';
include '../functions/func.php';
include '../functions/jdf.php';



//چک لاگین معلم
if($_SESSION['teacherchklogin']!=1)
{
	header ("location:teacher-login.php");
	exit;	
}


$mydate=jdate('Y/n/j');
$mytime=jdate('H:i');



$tid = $_SESSION['teacherid'];
$sql2 = "select * from tbl_teachers where id='".$tid."'";
$result2 = mysqli_query($con,$sql2);
$rows2 = mysqli_fetch_assoc($result2);

$fname2 = $rows2['fname'];
$lname2 = $rows2['lname'];
$madrak2 = $rows2['madrak'];
$reshte2 = $rows2['reshte'];
$tell2 = $rows2['tell'];
$avatar2 = $rows2['img'];
$username2=$rows2['username'];
$ncode2=$rows2['ncode'];
$fullname = $fname2 . " " . $lname2;


	
?>