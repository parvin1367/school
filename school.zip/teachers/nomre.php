<?php


include "teacher-rep.php";

if(isset($_GET["id"]) && isset($_GET["paye"]) && isset($_GET["reshte"]))
{

	if(isset($_POST['insert-marks']))
	{
		if($_POST['title']!="")
		{
			
			$title = myPrevent($_POST["title"]);
			$text = myPrevent($_POST["text"]);
			$date = myPrevent($_POST["date"]);
			
			$rnd=rand(1000000,9999999);

			$sql="INSERT INTO `tbl_marks` (`id`, `markid` ,`darsid` ,`tuname`, `marktitle`, `markdetails`,`date`,`markpaye`,`markreshte`) VALUES (NULL,'".$rnd."', '".$_GET["id"]."' , '".$username2."', '".$title."', '".$text."', '".$date."' , '".$_GET["paye"]."' , '".$_GET["reshte"]."');";
			$query=mysqli_query($con,$sql);
			if($query)
			{
				header("location:nomre-insert.php?markid=".$rnd."&courseid=".$_GET["id"]."&paye=".$_GET["paye"]."&reshte=".$_GET["reshte"]."");
				exit;
			}
			else
			{
				$erorr = "خطا در انجام عملیات";
			}
			
				
		}
		else
		{
			if($_POST['title'] == "") $titleerorr = "لطفا عنوانی برای امتحان وارد کنید.";
		}
	}
	else
	{
		
	}
}
else
{
	header("location:course-list.php");
	exit;	
}

	
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

	<?php
	include "head.php";
	?>
    
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
      <section id="main-content">
      
      <section class="wrapper">
                <!-- page start-->
                
				
                
                <div class="row">
                
                    <div class="col-lg-6" style="width:100%;">
                    
                    
                    
                 			   
                                
                                
                                <?php
								if(isset($erorr) && $erorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$erorr;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
                                <?php
								if(isset($titleerorr) && $titleerorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong>خطا در انجام عملیات : </strong> <?=$titleerorr;?>
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
                                
                                
                    
                        <section class="panel">
                            <header class="panel-heading">
                                ثبت نمرات ارزشیابی
                            </header>
                            <div class="panel-body">
                            
                            
                                <form role="form" method="post">
                                

                                
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">موضوع ارزشیابی</label>
                                        <input name="title" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>
                                    
                                   
                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">توضیحات ارزشیابی</label>
                                        <textarea name="text" class="form-control" id="exampleInputEmail1" style="height:100px;"></textarea>
                                    </div>
                                    
                                    
                                    
                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">تاریخ</label>
                                        <input name="date" type="text" class="form-control" id="exampleInputEmail1" value="<?php echo $mydate; ?>">
                                    </div>
                                    
                                    
                                   
                                    <br>
                                    
                                    <input type="submit" name="insert-marks" class="btn btn-info" value="ورود به بخش ثبت نمرات">
                                    <button class="btn btn-default" type="reset">پاک کردن فرم</button>
                                </form>

                            </div>
                        </section>
                    </div>
                    
                </div>
				
                
				
				
            </section>
            
            
            
            
	  </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
