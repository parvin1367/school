<?php

include "teacher-rep.php";



if(isset($_GET["editsuccess"]))
{
	$editsuccess="نمره دانش آموز با موفقیت ویرایش گردید.";	
}


if(isset($_GET["id"]))
{
	$did=$_GET["id"];	
}
else
	header("location:index.php");
	
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

    <?php
	include "head.php";
	?>
	
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
      <section id="main-content">
      
      <section class="wrapper">
                <!-- page start-->
                
				
				
                <div class="row">
                    <div class="col-lg-12">
                    
                    
                    
                    			<?php
								if(isset($editsuccess) && $editsuccess!="")
								{
								?>
                   				 <div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4>
                                        <i class="icon-ok-sign"></i>
                                        موفق!
                                  </h4>
                                    <p><?=$editsuccess;?></p>
                                </div>
                                <?php
								}
								?>
                    
                    
                        <section class="panel">
                        
                        
                        
                        <div class="inbox-head">
							<h3 style="float:right; font-weight:bold;margin-left:10px;">جستجو</h3>
                            <form class="pull-right position" method="post" style="width:40%;">
                                <div class="input-append">
                                    <input type="text" name="srch" placeholder="نام درس" class="sr-input" style="width:70%; ">
                                    <input type="submit" name="srchstud" class="btn sr-btn" value="بگرد">
                                </div>
                            </form>
                        </div>
                        
                        
                        
                            <header class="panel-heading">
                                
								<?php
								$ysryk="select * from tbl_course where id='".$did."'";
								$rtuymsr=mysqli_query($con,$ysryk);
								if(mysqli_num_rows($rtuymsr)>0)
								{
									$dtuykdjk=mysqli_fetch_assoc($rtuymsr);
									
								}
								?>
								
                                دانش آموزان پایه <?php echo $_GET["paye"]; ?> درس <?php echo $dtuykdjk["name"];?>
                         
                            </header>
                            <table class="table table-striped table-advance table-hover">
                                <thead>
                                    <tr>
										<th>#</th>
                                        <th>نام و نام خانوادگی</th>
                                        <th>نام پدر</th>
										<th>معدل درس</th>
										<th>تعداد ارزشیابی</th>
										<th>نمره آخرین ارزشیابی</th>
                                        <th>عملیات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                
                                <?php
								
								//برای سرچ
								if(isset($_POST["srchstud"]) && $_POST["srch"]!="")
								{
									
								}
								//نمایش کل دروس
                                else
								{
									$i=0;
									$sqlx = "select * from tbl_students where `paye`='".$_GET["paye"]."' && `reshte`='".$_GET["reshte"]."' order by `lname` asc ";
									$queryx = mysqli_query($con,$sqlx);
									while($fetchx = mysqli_fetch_assoc($queryx))
									{
										$i++;
										echo "<tr>";
										echo "<td>".$i."</td>";
										echo "<td>".$fetchx["fullname"]."</td>";
										echo "<td>".$fetchx["father"]."</td>";
										
										
										$sql3="select `markid` from `tbl_marks` where `tuname`='".$username2."' && `darsid`='".$did."' order by `id` desc";
										$query3=mysqli_query($con,$sql3);
										if(mysqli_num_rows($query3)>0)
										{
											$fetch3=mysqli_fetch_assoc($query3);
											$sql4="select `id`,`nomre` from `tbl_marksdetail` where `markid`='".$fetch3["markid"]."' && `suname`='".$fetchx["username"]."' ";
											$query4=mysqli_query($con,$sql4);
											if(mysqli_num_rows($query4)>0)
											{
												
												//for average
												$mynom=0;
												$j=0;
												
												$sql5="SELECT `nomre` FROM tbl_marksdetail INNER JOIN tbl_marks ON tbl_marksdetail.markid=tbl_marks.markid where tbl_marksdetail.suname='".$fetchx["username"]."' && tbl_marks.darsid='".$_GET["id"]."';";
												$query5=mysqli_query($con,$sql5);
												if(mysqli_num_rows($query5)>0)
												{
													while($fetch5=mysqli_fetch_assoc($query5))
													{
														if($fetch5["nomre"]!=0)
														{
															$mynomre=$fetch5["nomre"];
															$j++;
															$mynom+=$mynomre;
														}
													}
													if($mynom!=0)
													{
														$avenomre=($mynom/$j);
														$examCount=$j;
													}
													else
													{
														$avenomre=0;
														$examCount=0;
													}
													
												}
												else
												{
													$avenomre="-";
												}
												
												echo "<td>".round($avenomre,2)."</td>";
												
												echo "<td>".$examCount."</td>";
												
												
												
												$fetch4=mysqli_fetch_assoc($query4);
												$markid=$fetch4["id"];
												
												
												if($fetch4["nomre"]==0)
												{
													echo "<td><font color='red'>گزارش نشده</font></td>";
												}
												else
												{
													echo "<td>".$fetch4["nomre"]."</td>";
												}
											}
											else
											{
												$markid="error";
												echo "<td><font color='red'>تعریف نشده</font></td>";
											}
										}//end if query3
										else
										{
											$markid="error";
											echo "<td><font color='red'>ارزشیابی برای درس ثبت نشده است.</font></td>";
										}
										
										echo "<td><a class='btn btn-success btn-xs' style='color:#fff;' name='nomre-insert' href='nomre-edit-single.php?nid=".$markid."&suname=".$fetchx["username"]."&courseid=".$did."&paye=".$fetchx["paye"]."&reshte=".$fetchx["reshte"]."'><i class='icon-pencil'>"." "."ویرایش نمره آخرین ارزشیابی</i></a>";
										echo "<a class='btn btn-primary btn-xs' style='color:#fff;' name='nomre-insert' href='send-message-student.php?stuid=".$fetchx["username"]."'><i class='icon-pencil'>"." "."ارسال پیام</i></a></td>";

										
											
										echo "</tr>";
									}
								}
								
								?>
                                </tbody>
                            </table>
                        </section>
                        
                        
								<?php
								if(isset($erorr) && $erorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$erorr;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
                        
                        
                    </div>
                </div>
                <!-- page end-->
				
				
            </section>
            
            
            
            
	  </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
