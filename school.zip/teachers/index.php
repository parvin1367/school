<?php

include "teacher-rep.php";


?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

	<?php
	include "head.php";
	?>
    
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->
		
		
		
		
		<?php
		$sqlip="select * from tbl_log where `username`='".$username2."' order by `id` desc limit 1,1";
		$queryip=mysqli_query($con,$sqlip);
		if(mysqli_num_rows($queryip)>0)
		{
			$fetchip=mysqli_fetch_assoc($queryip);
		  ?>
		  
		  <p style="display:inline; text-align:left ;color: #fff; ;font-size:15px ; position: absolute; bottom: 1px; left: 6px;">آخرین ورود به سیستم : <?=$fetchip["date"]." - ".$fetchip["time"]?></p>
		  
		  <?php
			}
		  ?>
	  
	  
	  
      <!--main content start-->
      <?php include ("news-short.php"); ?>
      <!--main content end-->
	  
	  
	  
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
