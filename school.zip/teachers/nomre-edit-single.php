<?php

if(isset($_GET["nid"]) && isset($_GET["suname"]) && isset($_GET["courseid"]) && isset($_GET["paye"]) && isset($_GET["reshte"]))
{
	include("teacher-rep.php");
	
	
	$sqlcourse="select * from tbl_course where id='".$_GET["courseid"]."'";
	$querycourse=mysqli_query($con,$sqlcourse);
	$fetchcourse=mysqli_fetch_assoc($querycourse);
	$dname=$fetchcourse["name"];
	
}
else
{
	header("location:index.php");
	exit;
}

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>

<style type="text/css">

@font-face {
    font-family: iman;
    src: url(../styles/fonts/Yekan-modified.ttf);
}


*{
	font-family:iman;
}
.in{
}

table input{
	width:98%;
	text-align: center;
}

tr:nth-child(even){
	background-color:#eee;
}

td{
	padding:0 8px;
}

</style>

</head>

<body dir="rtl">
<center>


<br>
<?php
	echo "<h1>ویرایش نمرات درس  ".$dname."</h1>";
	echo "<h2>دانش آموزان پایه ".$_GET["paye"]." ".$_GET["reshte"]."</h2>";
?>

	
    <div class="result"></div>
    <form method="post">
  <table width="550" border="0" align="center">
    <tr>
      <td  bgcolor="#00CCFF" style="text-align: center; font-weight: bold;">نام و نام خانوادگی</td>
      <td  bgcolor="#00CCFF" style="text-align: center; font-weight: bold;">نمره</td>
    </tr>
    
	<?php
	$sqlstudent="select * from `tbl_marksdetail` where `id`='".$_GET["nid"]."' && `suname`='".$_GET["suname"]."'";
	$querystudent=mysqli_query($con,$sqlstudent);
	if(mysqli_num_rows($querystudent)>0)
	{
		$fetchstudent=mysqli_fetch_assoc($querystudent);
		
		$sql5="select `fullname` from tbl_students where `username`='".$_GET["suname"]."' ";
		$query5=mysqli_query($con,$sql5);
		if(mysqli_num_rows($query5)>0)
		{
			$fetch5=mysqli_fetch_assoc($query5);
		}
		
	?>
		<tr>
        <td><?php echo $fetch5["fullname"]; ?></td>
        <td><?php echo "<input type='text' name='nomre' class='nomre' value='".$fetchstudent["nomre"]."'>" ?></td>
        <tr>
    <?php
	}//while students
	
	echo "</table>";
	
	echo "<br>";
	echo "<input type='submit' class='in' name='in' value='ویرایش نمره'>&nbsp;";
	echo "<input type='submit' class='courselist' name='courselist' value='بازگشت به صفحه اصلی'>";
	
	
	
	if(isset($_POST['in']))
	{
		
		if($_POST["nomre"]>20 || $_POST["nomre"]<0)
		{
			echo "<br><br><font color='red'>نمره وارد شده صحیح نمی باشد : ".$_POST["nomre"]."</font>";
		}
		else
		{
			$dhkfh="UPDATE `tbl_marksdetail` SET `nomre` = '".$_POST["nomre"]."' WHERE `tbl_marksdetail`.`id` = '".$_GET["nid"]."';";
			$hjfn=mysqli_query($con,$dhkfh);
			
			if($hjfn)
			{
				//echo "<br><br><font color='green'>نمرات دانش آموزان با موفقیت ویرایش گردید.</font>";
				header("location:student-list.php?id=".$_GET['courseid']."&paye=".$_GET['paye']."&reshte=".$_GET['reshte']."&editsuccess=5456 ");
				exit;
			}
			else
			{
				echo "<br><br><font color='red'>خطا در عملیات ویرایش نمرات</font>";
			}
		}
	}
	else if(isset($_POST['courselist']))
	{
		header("location:index.php");
		exit;
	}
  
  ?>
  </form>
</center>
</body>
</html>