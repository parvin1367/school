<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>ورود معلم</title>

  <?php include ('head.php');?>
    
</head>

  <body class="login-body">
  
  
  <?php

if(isset($_GET["cerror"]))
{
	echo "<script>alert('کد امنیتی وارد شده اشتباه می باشد')</script>";
}  
  
  
if(isset($_GET["empty"]))
{
    //echo "<font color=#FF0000>لطفا فیلد ها را پر کنید</font>";
	echo "<script>alert('لطفا فیلد ها را پر کنید')</script>";
}

if(isset($_GET["error"]))
{
	echo "<script>alert('نام کاربری یا کلمه عبور شما اشتباه می باشد')</script>";
}

?>
  

    <div class="container">

      <form class="form-signin" method="post" action="check-login.php">
        <h2 class="form-signin-heading">ورود به پنل مدیریت</h2>
        <div class="login-wrap">
		<?php
		if(!isset($_SESSION['teacherchklogin']))
		{
		?>
            <input name="user" type="text" autofocus class="form-control" id="user" placeholder="نام کاربری">
            <input name="pass" type="password" class="form-control" id="pass" placeholder="کلمه عبور">
            
			<center>
			<img style="width:90%;height:40px; margin:0 10px;border-radius:10px;" src="../functions/captcha.php" >
			</center>
			
			<input name="captcha" type="text" class="form-control" id="pass" placeholder="کد امنیتی">
            
			
            <input class="btn btn-lg btn-login btn-block" type="submit" name="login" id="login" value="ورود">
		<?php
		}
		else
		{
		?>
			<p>شما قبلا وارد سیستم شده اید</p>
			<br>
			<center>
			<a href="index.php" class="btn btn-info" style="color:#fff;">ورود به حساب کاربری</a>
			<a href="teacher-logout.php" class="btn btn-danger" style="color:#fff;">خروج از سیستم</a>
			</center>
			<br>
		<?php
		}
		?>
			<br>
          <p>سیستم مدیریت مدرسه</p>
          <center><i>.....</i></center>

        </div>

      </form>

    </div>


  </body>
</html>
