<?php


include "teacher-rep.php";


	if(isset($_GET["updateok"]))
	{
		$editok="ویرایش > موفق";
	}
	if(isset($_GET["deleteok"]))
	{
		$deleteok="حذف > موفق";
	}
	
	
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

	<?php
	include "head.php";
	?>
  <link rel="stylesheet" type="text/css" href="print.css" media="print">
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
      <section id="main-content">
      
      <section class="wrapper">
                <!-- page start-->
                
				
                
                <div class="row">
                
                    <div class="col-lg-6" style="width:100%;">
                    
                    
                    
                 			   <?php
								if(isset($success) && $success!="")
								{
								?>
                   				 <div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4>
                                        <i class="icon-ok-sign"></i>
                                        موفق!
                                  </h4>
                                    <p><?=$success;?></p>
                                </div>
                                <?php
								}
								?>
								
								
								<?php
								if(isset($deleteok) && $deleteok!="")
								{
								?>
                   				 <div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4>
                                        <i class="icon-ok-sign"></i>
                                        موفق!
                                  </h4>
                                    <p><?=$deleteok;?></p>
                                </div>
                                <?php
								}
								?>
								
								
								
								<?php
								if(isset($editok) && $editok!="")
								{
								?>
                   				 <div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4>
                                        <i class="icon-ok-sign"></i>
                                        موفق!
                                  </h4>
                                    <p><?=$editok;?></p>
                                </div>
                                <?php
								}
								?>
								
								
								
                                
                                
                                <?php
								if(isset($erorr) && $erorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$erorr;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
								
								
								<?php
								if(isset($selecterror) && $selecterror!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$selecterror;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
								
								
								
								<?php
								if(isset($selerr) && $selerr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$selerr;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
                                
                         

                    </div>
                    
                </div>
				
                
                
                
				
                <div class="row">
                    <div class="col-lg-12">
                        <section class="panel">
                            <header class="panel-heading">
                                
                                برنامه هفتگی
								
								<br>
								
								<div class="panel-body" style="margin-top:1px;float:right;">
									<a href="?dai=21" class="btn btn-success"><i class="icon-list"></i> لیست کل </a>
								</div>
								
								<div class="panel-body" style="float:right;">
									<a href="?day=0" class="btn btn-shadow btn-default">شنبه</a>
									<a href="?day=1" class="btn btn-shadow btn-danger">یک شنبه</a>
									<a href="?day=2" class="btn btn-shadow btn-warning">دو شنبه</a>
									<a href="?day=3" class="btn btn-shadow btn-success">سه شنبه</a>
									<a href="?day=4" class="btn btn-shadow btn-info">چهار شنبه</a>
									<a href="?day=5" class="btn btn-shadow btn-primary">پنج شنبه</a>
								</div>
								
								<div class="panel-body" style="float:left;">
									<a href="?print=54" class="btn btn-info "><i class="icon-print"></i> پرینت برنامه هفتگی </a>
								</div>
								
								
							<?php
							
							
								if(isset($_GET['print']))
								{
								?>
									<script>
										javascript:window.print();
									</script>
								<?php
								}
							
								if(isset($_GET["day"]))
								{
									switch ($_GET["day"])
									{
										case 0:
											$sql = "select * from `tbl_proweek` where `teacherid`='".$username2."' && `day`='0' order by `hour` asc";
											break;
										case 1:
											$sql = "select * from `tbl_proweek` where  `teacherid`='".$username2."' && `day`='1' order by `hour` asc";
											break;
										case 2:
											$sql = "select * from `tbl_proweek` where  `teacherid`='".$username2."' && `day`='2' order by `hour` asc";
											break;
										case 3:
											$sql = "select * from `tbl_proweek` where  `teacherid`='".$username2."' && `day`='3' order by `hour` asc";
											break;
										case 4:
											$sql = "select * from `tbl_proweek` where  `teacherid`='".$username2."' && `day`='4' order by `hour` asc";
											break;
										case 5:
											$sql = "select * from `tbl_proweek` where  `teacherid`='".$username2."' && `day`='5' order by `hour` asc";
											break;
										default:
											$sql = "select * from `tbl_proweek` where `teacherid`='".$username2."'  order by `day` asc";
									}
								}
								else
								{
									$sql = "select * from `tbl_proweek` where `teacherid`='".$username2."'  order by `day`,`hour` asc";
								}
								

							?>							
                         
                            </header>
                            <table class="table table-striped table-advance table-hover">
                                <thead>
                                    <tr>
										<th>#</th>
                                        <th>نام درس</th>
										<th>پایه</th>
										<th>رشته</th>
                                        <th>روز هفته</th>
                                        <th>ساعت (زنگ)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                
                                <?php
								
								$i=0;
								$query = mysqli_query($con,$sql);
								while($fetch = mysqli_fetch_assoc($query))
								{
									$i++;
									
									switch ($fetch["paye"])
									{
										case 2:
											$p="<span class='label label-primary label-mini'>دوم دبیرستان</span>";
											break;
										case 3:
											$p="<span class='label label-info label-mini'>سوم دبیرستان</span>";
											break;
										case 7:
											$p="<span class='label label-danger'>هفتم</span>";
											break;
										case 8:
											$p="<span class='label label-warning'>هشتم</span>";
											break;
										case 9:
											$p="<span class='label label-success'>نهم</span>";
											break;
										default:
											$p="نا معتبر";
									}
									
									
									switch($fetch["day"]){
										case 0:
											$dayweek="شنبه";
											break;
										case 1:
											$dayweek="یک شنبه";
											break;
										case 2:
											$dayweek="دو شنبه";
											break;
										case 3:
											$dayweek="سه شنبه";
											break;
										case 4:
											$dayweek="چهار شنبه";
											break;
										case 5:
											$dayweek="پنج شنبه";
											break;
										default:
											$dayweek="تعریف نشده";
									}
									
									
									$sql6 = "select `name`,`teacherid` from `tbl_course` where `id`='".$fetch["courseid"]."'";
									$query6 = mysqli_query($con,$sql6);
									$fetch6 = mysqli_fetch_assoc($query6);
									
									echo "<tr>";
									echo "<td>".$i."</td>";
									echo "<td>".$fetch6["name"]."</td>";
									echo "<td>".$p."</td>";
									echo "<td>".$fetch["reshte"]."</td>";
									echo "<td>".$dayweek."</td>";
									echo "<td>".$fetch["hour"]."</td>";
									$x=$fetch["id"];
									
									echo "</tr>";
								}
								
								?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </div>
                <!-- page end-->
				
				
            </section>
            
			
            <script type="text/javascript">
				function del(id)
				{
					var x=confirm("آیا از حذف درس اطمینان دارید؟");
					if(x==true)
					{
						window.location.href="proweek-delete.php?id="+id;
					}
					else
					{
						window.location.href="#";
					}
				}
			</script>
			
            
            
	  </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
