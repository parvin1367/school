<?php

if(isset($_GET["id"]) && isset($_GET["courseid"]) && isset($_GET["paye"]) && isset($_GET["reshte"]))
{
	include("teacher-rep.php");
	
	
	$sqlcourse="select * from tbl_course where id='".$_GET["courseid"]."'";
	$querycourse=mysqli_query($con,$sqlcourse);
	$fetchcourse=mysqli_fetch_assoc($querycourse);
	$dname=$fetchcourse["name"];

}
else
{
	header("location:index.php");
	exit;
}

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>

<link rel="stylesheet" type="text/css" href="print.css" media="print">

<style type="text/css">

@font-face {
    font-family: iman;
    src: url(../styles/fonts/Yekan-modified.ttf);
}


*{
	font-family:iman;
}
.in{
}

table input{
	width:98%;
	text-align: center;
}

tr:nth-child(even){
	background-color:#eee;
}

td{
	padding:0 8px;
}

</style>

</head>

<body dir="rtl">
<center>


<br>
<?php
	echo "<h1>نمرات درس  ".$dname."</h1>";
	echo "<h2>دانش آموزان پایه ".$_GET["paye"]." ".$_GET["reshte"]."</h2>";

?>

	
    <div class="result"></div>
    <form method="post">
  <table width="550" border="0" align="center">
    <tr>
	  <td  bgcolor="#00CCFF" style="text-align: center; font-weight: bold;">#</td>
      <td  bgcolor="#00CCFF" style="text-align: center; font-weight: bold;">نام و نام خانوادگی</td>
      <td  bgcolor="#00CCFF" style="text-align: center; font-weight: bold;">نمره</td>
    </tr>
    
	<?php
	$i=0;
	$markid=$_GET['id'];
	$sqlstudent="select * from `tbl_students` where `paye`='".$_GET["paye"]."' && `reshte`='".$_GET["reshte"]."' order by `lname`";
	$querystudent=mysqli_query($con,$sqlstudent);
	while($fetchstudent=mysqli_fetch_assoc($querystudent))
	{
		$i++;
		?>
        
		<tr>
        <td><?php echo $i; ?></td>
        <td><?php echo $fetchstudent["fullname"]; ?></td>
        
        <?php
		$sqlmrk="select * from `tbl_marksdetail` where `markid`='".$markid."' && `suname`='".$fetchstudent['username']."' ";
		$querymrk=mysqli_query($con,$sqlmrk);
		while($fetchmrk=mysqli_fetch_assoc($querymrk))
		{
	?>
            
            <td><?php echo "<input type='text' name='qnomre_$i' class='qnomre_$i' value='".$fetchmrk['nomre']."'>" ?></td>
            </tr>
            <td><?php echo "<input type='hidden' name='idmrk_$i' class='idmrk_$i' value='".$fetchmrk["id"]."'>" ?></td>
            <td><?php echo "<input type='hidden' name='qmarkid_$i' class='qmarkid_$i' value='$markid'>" ?></td>
            <td><?php echo "<input type='hidden' name='quname_$i' class='quname_$i' value='".$fetchstudent['username']."'>" ?></td>
        
     
	<?php
		}//while stu
	}//while students
	
	echo "</table>";
	
	echo "<br>";
	echo "<input type='submit' class='print' name='print' value='پرینت نمرات'>&nbsp;";
	echo "<input type='submit' class='courselist' name='courselist' value='بازگشت به ارشیو ارزشیابی'>";
	
	$count=$i;
	
	if(isset($_POST['print']))
	{
	?>
		<script>
			javascript:window.print();
		</script>
	<?php
	}
	else if(isset($_POST['courselist']))
	{
		header("location:nomre-archive.php");
		exit;
	}
  
  ?>
  </form>
</center>
</body>
</html>