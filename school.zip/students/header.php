<?php

	$sid = $_SESSION['studentid'];
	$sql = "select * from tbl_students where id='".$sid."'";
	$result = mysqli_query($con,$sql);
	$rows = mysqli_fetch_assoc($result);
	
	$fname = $rows['fname'];
	$lname = $rows['lname'];
	$avatar = $rows['image'];
	$fullname = $fname . " " . $lname;

?>







<header class="header white-bg" style="top:0; min-height:70px; line-height:35px;">
            <div class="sidebar-toggle-box">
                <div data-original-title="Toggle Navigation" data-placement="right" class="icon-reorder tooltips"></div>
            </div>
            
            
            
            
            
            
            
            
            <!--logo start-->
            <a href="#" class="logo">دبیرستان <span><?php echo $_SESSION['schooltitle']; ?></span></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">
                    
                    

          <?php
          $msg=0;
          $sqlmsg="select * from tbl_messages_stu where `to`='".$username2."' AND `state`='1' order by `id` desc";
          $querymsg=mysqli_query($con,$sqlmsg);
          $countmsg=mysqli_num_rows($querymsg);
          $sqlmsg2="select * from tbl_messages_tea where `to`='".$username2."' AND `state`='1' order by `id` desc";
          $querymsg2=mysqli_query($con,$sqlmsg2);
          $countmsg2=mysqli_num_rows($querymsg2);
          if($countmsg>0 || $countmsg2>0)
          {
            $msg=$countmsg+$countmsg2;
          }
          ?>

                  <!-- inbox dropdown start-->
                  <li id="header_inbox_bar" class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                      <i class="icon-envelope-alt"></i>
                      <span class="badge bg-important">
							<?php
              if($msg>0)
                echo $msg;
              ?>
							</span>
                    </a>
                    <ul class="dropdown-menu extended inbox">
                      <div class="notify-arrow notify-arrow-red"></div>
                      <li>
                        <?php
                        if($msg==0)
                        {
                          ?>
                          <p class="red">شما پیام جدیدی ندارید</p>
                          <?php
                        }
                        else
                        {
                          ?>
                          <p class="red">شما <?php echo $msg; ?> پیام جدید دارید</p>
                          <?php
                        }
                        ?>
                      </li>


                      <?php
                      if($countmsg>0)
                      {
                        ?>
                        <li>
                          <a href="admin-messages-recived.php">
                                    <span class="subject">
                                    <span class="from">دریافتی از مدیر</span>
                                    <span class="time"><?php echo $countmsg ?></span>
                                    </span>
                            <span class="message">
                                       مشاهده پیام ها
                                    </span>
                          </a>
                        </li>
                        <?php
                      }
                      ?>

                      <?php
                      if($countmsg2>0)
                      {
                        ?>

                        <li>
                          <a href="teacher-messages-recived.php">
                                    <span class="subject">
                                    <span class="from">دریافتی از معلمان</span>
                                    <span class="time"><?php echo $countmsg2 ?></span>
                                    </span>
                            <span class="message">
                                       مشاهده پیام ها
                                    </span>
                          </a>
                        </li>
                        <?php
                      }
                      ?>

                    </ul>
                  </li>
                  <!-- inbox dropdown end -->
                    
                </ul>
                <!--  notification end -->
            </div>
            
            
            
            
            
            
            <div class="top-nav ">
                <!--search & user info start-->
                <ul class="nav pull-right top-menu">
                    <li>
                        <input type="text" class="form-control search" placeholder="Search">
                    </li>
                    <!-- user login dropdown start-->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <img alt="" style="width:39px;height:45px;" src=<?="../".$avatar;?>>
                            <span class="username"><?php echo $fullname; ?></span>
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu extended logout" style="width:100% !important;">
                            <div class="log-arrow-up"></div>
                            <!--
							<li ><a href="admin-edit.php"><i class=" icon-suitcase"></i>ویرایش اطلاعات</a></li>
                            <li><a href="#"><i class="icon-cog"></i> تنظیمات</a></li>
                            <li><a href="#"><i class="icon-bell-alt"></i> اعلام ها</a></li>
                            -->
                            <li><a href="student-logout.php"><i class="icon-key"></i> خروج</a></li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->
                </ul>
                <!--search & user info end-->
            </div>
            <!-- End Top nav -->
            
            
            
            
            
        </header>