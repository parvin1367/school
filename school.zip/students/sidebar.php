<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">
                  <li class="active">
                      <a class="" href="index.php">
                          <i class="icon-home"></i>
                          <span>صفحه اصلی</span>
                      </a>
                  </li>
				  
				  
				  <li>
                      <a class="" href="info.php">
                          <i class="icon-user"></i>
                          <span>آمار و اطلاعات</span>
                      </a>
                  </li>
				  
				  
				  <li>
                      <a class="" href="news.php">
                          <i class="icon-bullhorn"></i>
                          <span>اخبار مدرسه</span>
                      </a>
                  </li>
				  
				  
				  <li>
                      <a class="" href="proweek.php">
                          <i class="icon-file-text"></i>
                          <span>برنامه هفتگی</span>
                      </a>
                  </li>
                  
                  
                  
				  <li>
                      <a class="" href="nomre-archive.php">
                          <i class="icon-book"></i>
                          <span>کارنامه</span>
                      </a>
                  </li>
				  
                  
                  
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon-envelope-alt"></i>

                <?php
                $msg=0;
                $sqlmsg="select * from tbl_messages_stu where `to`='".$username2."' AND `state`='1' order by `id` desc";
                $querymsg=mysqli_query($con,$sqlmsg);
                $countmsg=mysqli_num_rows($querymsg);
                $sqlmsg2="select * from tbl_messages_tea where `to`='".$username2."' AND `state`='1' order by `id` desc";
                $querymsg2=mysqli_query($con,$sqlmsg2);
                $countmsg2=mysqli_num_rows($querymsg2);
                if($countmsg>0 || $countmsg2>0)
                {
                  $msg=$countmsg+$countmsg2;
                }
                ?>
						  
						  <span class="label label-danger pull-right mail-info"><?php if($msg>0) {echo $msg;} ?></span>

                          <span>مدیریت پیام ها</span>
                          <span class="arrow"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="admin-messages-recived.php">دریافتی از مدیر</a></li>
                          <li><a class="" href="admin-messages-sent.php">ارسالی برای مدیر</a></li>
                          <li><a class="" href="send-message-admin.php">ارسال پیام برای مدیر</a></li>
                          <li><a class="" href="teacher-messages-recived.php">دریافتی از معلمان</a></li>
						              <li><a class="" href="teacher-messages-sent.php">ارسالی برای معلمان</a></li>
                          <li><a class="" href="send-message-teacher.php">ارسال پیام برای معلمان</a></li>
                      </ul>
                  </li>
                  
				  
                  <li>
                      <a class="" href="send-poll.php">
                          <i class="icon-comments-alt"></i>
                          <span>ارسال نظر و پیشنهاد</span>
                      </a>
                  </li>
				  
				  
				  
                  
                  <li>
                      <a class="" href="student-logout.php">
                          <i class="icon-user"></i>
                          <span>خروج از حساب مدیریت</span>
                      </a>
                  </li>
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>