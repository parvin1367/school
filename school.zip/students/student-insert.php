<?php
session_start();
include '../functions/connection.php';
include '../functions/func.php';
include '../functions/jdf.php';

$mydate=jdate('Y/n/j');
$mytime=jdate('H:i');


$sqlsettings="select student_signup from tbl_settings";
$querysettings=mysqli_query($con,$sqlsettings);
$fetchsettings=mysqli_fetch_assoc($querysettings);
if($fetchsettings["student_signup"] == false){
  header ("location:student-login.php");
  exit;
}



	if(isset($_POST['save-student']))
	{
		
		
		$uppic="images/students/default.jpg";
			
		//آپلود عکس
		if($_FILES["file"]["name"]!="")
		{
			if($_FILES["file"]["error"]>0)
			{
				echo "<script>alert('خطای آپلود فایل تصویر')</script>";
			}
			else
			{
				$filename=$_FILES["file"]["name"];
				$filetype=$_FILES["file"]["type"];
				$temp=$_FILES["file"]["tmp_name"];
				
				$whitelist=array("image/jpeg","image/jpg","image/png","image/gif");
				$myfile=md5($filename.microtime()).substr($filename,-5,5);
				$save_url="../images/students/";
				$db_url="images/students/".$myfile;
				if(in_array($filetype,$whitelist))
				{
					if(is_uploaded_file($temp))
					{
						$uppic="";
						$m=move_uploaded_file($temp,$save_url.$myfile);
						if($m)
						{
							$uppic=$db_url;
							echo "<script>alert('موفق در آپلود تصویر')</script>";
						}
						else
						{
							echo "<script>alert('خطای آپلود تصویر')</script>";
						}
					}
				}
				else
				{
					echo "<script>alert('خطای فرمت فایل تصویر')</script>";
				}
			}
		}
		
			
		if($_POST['fname']!="" && $_POST['lname']!="" && $_POST['username']!="" && $_POST['ncode']!="")
		{

      $username = myPrevent($_POST["username"]);

      $sqlll = "select * from tbl_students where username='".$username."'";
      $query = mysqli_query($con,$sqlll);
      if(mysqli_num_rows($query) != 0) {
        echo "<script>alert('کد دانش آموزی وارد شده قبلا ثبت شده است')</script>";
        exit;
      }

			$password = myHashData("sha1",$_POST["ncode"]);
			$fname = myPrevent($_POST["fname"]);
			$lname = myPrevent($_POST["lname"]);
			$ncode = myPrevent($_POST["ncode"]);
      $shomareshenasname = myPrevent($_POST["shomareshenasname"]);
			$father = myPrevent($_POST["father"]);
			$bdate = myPrevent($_POST["bdate"]);
			$tell = myPrevent($_POST["tell"]);
			$fathertell = myPrevent($_POST["fathertell"]);
			$mothertell = myPrevent($_POST["mothertell"]);
			$address = myPrevent($_POST["address"]);
			$fatherworkaddress = myPrevent($_POST["fatherworkaddress"]);
			$motherworkaddress = myPrevent($_POST["motherworkaddress"]);
			$reshte = myPrevent($_POST["reshte"]);
			$paye = myPrevent($_POST["paye"]);
			$pass = myPrevent($password);
			
			$fnamelname= $fname." ".$lname;

			$sql="INSERT INTO `tbl_students` (`id`, `fname`, `lname`, `fullname` , `ncode` , `father`, `bdate`, `tell`, `address`, `reshte`, `paye`, `username`, `password` , `image` , `father_work_address` , `mother_work_address` , `father_phone_number` , `mother_phone_number` , `shenasname_code`) VALUES (NULL, '".$fname."', '".$lname."', '".$fnamelname."' , '".$ncode."' , '".$father."', '".$bdate."', '".$tell."', '".$address."', '".$reshte."', '".$paye."', '".$username."', '".$pass."' , '".$uppic."', '".$fatherworkaddress."', '".$motherworkaddress."', '".$fathertell."', '".$mothertell."', '".$shomareshenasname."')";

			$query=mysqli_query($con,$sql);
			if($query)
			{
				$success = $fname . " " . $lname . " با موفقیت ثبت شد.";
				echo "<script>alert('شما با موفقیت ثبت نام شدید، اکنون می توانید وارد سیستم شوید');</script>";
				header("Location: student-login.php");
				exit;
			}
			else
			{
				$erorr = "خطا در عملیات ثبت";
			}
		}
		else
		{
			if($_POST['fname'] == "") $fnameerror = "فیلد نام دانش آموز را پر کنید";
			if($_POST['lname'] == "") $lnameerror = "فیلد نام خانوادگی دانش آموز را پر کنید";
			if($_POST['username'] == "") $usernameerror = "فیلد کد دانش آموزی را پر کنید";
			if($_POST['ncode'] == "") $passworderror = "فیلد کد ملی دانش آموز را پر کنید";
		}
	}
	else
	{
		
	}
	
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>ثبت نام دانش آموزان</title>

    <meta charset="utf-8">

    <meta name="robots" content="noindex, nofollow">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="codenvato, iman parhizkar">
    <link rel="shortcut icon" href="../styles/img/favicon.html">
    <!-- Bootstrap core CSS -->
    <link href="../styles/css/bootstrap.min.css" rel="stylesheet">
    <link href="../styles/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="../styles/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <link rel="stylesheet" href="../styles/css/owl.carousel.css" type="text/css">
    <!-- Custom styles for this template -->
    <link href="../styles/css/style.css" rel="stylesheet">
    <link href="../styles/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="../styles/js/html5shiv.js"></script>
    <script src="../styles/js/respond.min.js"></script>
    <![endif]-->

    <style>
      #main-content {
         margin-right: 0px;
      }
      .wrapper{
        margin-top: 0px;
      }
    </style>
    
  </head>

  <body>

  <section id="container" class="">
  


	  
      <!--main content start-->
      <section id="main-content">
      
      <section class="wrapper">
                <!-- page start-->
                
				
                
                <div class="row">
                
                    <div class="col-lg-5 col-md-6" style="margin: 10px auto;float: none">
                    
                    
                    
                 			   <?php
								if(isset($success) && $success!="")
								{
								?>
                   				 <div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4>
                                        <i class="icon-ok-sign"></i>
                                        موفق!
                                  </h4>
                                    <p><?=$success;?></p>
                                </div>
                                <?php
								}
								?>
                                
                                
                                <?php
								if(isset($erorr) && $erorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$erorr;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
                                <?php
								if(isset($uploaderorr) && $uploaderorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$uploaderorr;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                <?php
								if(isset($pasvanderorr) && $pasvanderorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$pasvanderorr;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                <?php
								if(isset($httperorr) && $httperorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$httperorr;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
                                
                                <?php
								if(isset($usernameerorr) && $usernameerorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong>خطا در انجام عملیات : </strong> <?=$usernameerorr;?>
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
                                <?php
								if(isset($fnameerror) && $fnameerror!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong>خطا در انجام عملیات : </strong> <?=$fnameerror;?>
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                <?php
								if(isset($lnameerror) && $lnameerror!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong>خطا در انجام عملیات : </strong> <?=$lnameerror;?>
                             
                                </div>
                                <?php
								}
								?>
                                
                                <?php
								if(isset($usernameerror) && $usernameerror!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong>خطا در انجام عملیات : </strong> <?=$usernameerror;?>
                             
                                </div>
                                <?php
								}
								?>
                                
                                <?php
								if(isset($passworderror) && $passworderror!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong>خطا در انجام عملیات : </strong> <?=$passworderror;?>
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
                    
                        <section class="panel">
                            <header class="panel-heading">
                                ثبت نام دانش آموز جدید
                         
                            </header>
                            <div class="panel-body">
                            
                            <font>* پر کردن فیلد های ستاره دار الزامی می باشد.</font><br>
							<font>* کد دانش آموزی بعنوان نام کاربری و کدملی بعنوان رمز عبور دانش آموز در نظر گرفته می شوند.</font>
							<br><br>
                            
                                <form role="form" enctype="multipart/form-data" method="post">
                                    
									<div class="form-group">
                                        <label for="exampleInputEmail1"><font color="red">*</font>کد دانش آموزی</label>
                                        <input name="username" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>
									
									
									<div class="form-group">
                                        <label for="exampleInputEmail1"><font color="red">*</font>نام</label>
                                        <input name="fname" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1"><font color="red">*</font>نام خانوادگی</label>
                                        <input name="lname" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>
									
									
									                <div class="form-group">
                                        <label for="exampleInputEmail1"><font color="red">*</font>کد ملی</label>
                                        <input name="ncode" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>


									                <div class="form-group">
                                        <label for="exampleInputEmail1">شماره شناسنامه</label>
                                        <input name="shomareshenasname" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>

                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">نام پدر</label>
                                        <input name="father" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">تاریخ تولد</label>
                                        <input name="bdate" type="text" class="form-control" id="exampleInputEmail1" placeholder="با فرمت درست وارد شود : 25-06-1375">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">شماره تماس</label>
                                        <input name="tell" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>


                                    <div class="form-group">
                                      <label for="exampleInputEmail1">شماره تماس پدر</label>
                                      <input name="fathertell" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>


                                    <div class="form-group">
                                      <label for="exampleInputEmail1">شماره تماس مادر</label>
                                      <input name="mothertell" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>

                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">آدرس منزل</label>
                                        <input name="address" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>

                                  <div class="form-group">
                                        <label for="exampleInputEmail1">آدرس محل کار پدر</label>
                                        <input name="fatherworkaddress" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>

                                  <div class="form-group">
                                        <label for="exampleInputEmail1">آدرس محل کار مادر</label>
                                        <input name="motherworkaddress" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>

									
                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">پایه</label>
                                        <select name="paye" style="width:100%">
                                          <option value="7">هفتم</option>
                                          <option value="8">هشتم</option>
                                          <option value="9">نهم</option>
                                          <option value="2">دوم دبیرستان</option>
                                          <option value="3">سوم دبیرستان</option>
                                        </select>
                                    </div>
									
                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">رشته:</label>
                                        <select name="reshte" style="width:100%">
                                        	<option value="عمومی">عمومی</option>
                                          <option value="انسانی">علوم انسانی</option>
                                          <option value="تجربی">علوم تجربی</option>
                                          <option value="ریاضی">ریاضی</option>
                                        </select>
                                    </div>
                                    

                                    
                                    <div class="form-group">
                                        <label for="exampleInputFile">تصویر دانش آموز</label>
                                        <input name="file" type="file" class="form-control" id="bdate">
                                    </div>
                                    <br>
                                    
									
                                    <input type="submit" name="save-student" class="btn btn-info" value="ثبت کردن دانش آموز">
                                    <button class="btn btn-default" type="reset">پاک کردن فرم</button>
                                </form>

                            </div>
                        </section>
                    </div>
                    
                </div>
				
                
                
                
				
                
				
				
            </section>
            
            
            
            
	  </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
