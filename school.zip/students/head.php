<meta charset="utf-8">

<meta name="robots" content="noindex, nofollow">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="author" content="codenvato, iman parhizkar">
<link rel="shortcut icon" href="../styles/img/favicon.html">
<!-- Bootstrap core CSS -->
<link href="../styles/css/bootstrap.min.css" rel="stylesheet">
<link href="../styles/css/bootstrap-reset.css" rel="stylesheet">
<!--external css-->
<link href="../styles/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
<link rel="stylesheet" href="../styles/css/owl.carousel.css" type="text/css">
<!-- Custom styles for this template -->
<link href="../styles/css/style.css" rel="stylesheet">
<link href="../styles/css/style-responsive.css" rel="stylesheet" />

<style type="text/css">
  body{
    background-image: url('../<?php echo $_SESSION["background"]; ?>') !important;
    background-repeat: no-repeat !important;
    background-size: cover !important;
    background-attachment: fixed !important;
  }
</style>


<!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
<!--[if lt IE 9]>
<script src="../styles/js/html5shiv.js"></script>
<script src="../styles/js/respond.min.js"></script>
<![endif]-->