<?php


include "student-rep.php";


	if(isset($_POST['send-message']))
	{
		if($_POST['title']!="" && $_POST['text']!="")
		{
			
			$title = myPrevent($_POST["title"]);
			$text = myPrevent($_POST["text"]);
			

			$sql="INSERT INTO `tbl_polls` (`id`, `title`, `text`, `date`, `state`) VALUES (NULL, '".$title."', '".$text."', '".$mydate."', '1');";
			
			
			$query=mysqli_query($con,$sql);
			if($query)
			{
				$success = "ارسال با موفقیت انجام شد";
			}
			else
			{
				$erorr = "خطا در ارسال";
			}
			
				
		}
		else
		{
			if($_POST['title'] == "") $titleerorr = "لطفا موضوع را انتخاب کنید";
			if($_POST['text'] == "") $texterror = "لطفا متن نظر، پیشنهاد و یا انتقاد خود را وارد کنید";
		}
	}
	else
	{
	}

	
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

	<?php
	include "head.php";
	?>
    
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
      <section id="main-content">
      
      <section class="wrapper">
                <!-- page start-->
                
				
                
                <div class="row">
                
                    <div class="col-lg-6" style="width:100%;">
                    
                    
                    
                 			   <?php
								if(isset($success) && $success!="")
								{
								?>
                   				 <div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4>
                                        <i class="icon-ok-sign"></i>
                                        موفق!
                                  </h4>
                                    <p><?=$success;?></p>
                                </div>
                                <?php
								}
								?>
                                
                                
                                <?php
								if(isset($erorr) && $erorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong><?=$erorr;?></strong> 
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
                                <?php
								if(isset($titleerorr) && $titleerorr!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong>خطا در انجام عملیات : </strong> <?=$titleerorr;?>
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
                                <?php
								if(isset($texterror) && $texterror!="")
								{
								?>
                                <div class="alert alert-block alert-danger fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <strong>خطا در انجام عملیات : </strong> <?=$texterror;?>
                             
                                </div>
                                <?php
								}
								?>
                                
                                
                                
                    
                        <section class="panel">
                            <header class="panel-heading">
                                ارسال نظر، پیشنهاد و انتقاد برای مدیر - نام و مشخصات شما درج نخواهد شد
                            </header>
                            <div class="panel-body">
                            
                            
                                <form role="form" method="post">
                                

                                
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">موضوع</label>
                                        <input name="title" type="text" class="form-control" id="exampleInputEmail1" >
                                    </div>
                                    
                                   
                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">متن</label>
                                        <textarea name="text" class="form-control" id="exampleInputEmail1" style="height:100px;"></textarea>
                                    </div>
                                    
                                   
                                    <br>
                                    
                                    <input type="submit" name="send-message" class="btn btn-info" value="ارسال">
                                    <button class="btn btn-default" type="reset">پاک کردن فرم</button>
                                </form>

                            </div>
                        </section>
                    </div>
                    
                </div>
				
                
				
				
            </section>
            
            
            
            
	  </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
