<style type="text/css">
			.myul{
				text-align:center;
				background-color: rgba(0,0,0,0.45);
				margin: 10px;
				border-radius: 10px;
			}
			.myli{
				padding: 5px;
				border-bottom: 1px solid #888;
				color: #fff;
			}
			.myli:first-child{
				background-color: rgba(0,0,0,0.2);
				font-size: 18px;
				border-radius: 10px;
			}
			.myli:last-child{
				border-bottom: none;
			}
		</style>
		
		
		
		<!--main content start-->
        <section id="main-content">
            <section class="wrapper">
                <!-- page start-->
                <div class="row">
				<?php
				$sql = "select * from tbl_news where `to`='1' || `to`='0' order by `id` desc limit 0,3";
				$query = mysqli_query($con,$sql);
				if(mysqli_num_rows($query)>0)
				{
				?>
					<ul class="myul">
					<li class="myli">آخرین اخبار مدرسه</li>
						
						<?php
						while($fetch = mysqli_fetch_assoc($query))
						{
						?>
						
							<li class="myli"><?php echo "<b>".$fetch["title"]."</b> : <span style='color:#ddd;'>".substr($fetch["text"],0,200)."...</span>" ?></li>
						
						<?php
						}
						?>
						
					</ul>
				<?php
				}
				?>
                </div>
                <!-- page end-->
            </section>
        </section>
        <!--main content end-->