<?php


include "student-rep.php";

	
	
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    

    <title>پنل مدیریت : <?php echo $fullname; ?></title>

	<?php
	include "head.php";
	?>
    
  </head>

  <body>

  <section id="container" class="">
  
      <!--header start-->
	  <?php include ("header.php"); ?>
      <!--header end-->
      
      
      <!--sidebar start-->
      <?php include ("sidebar.php"); ?>
      <!--sidebar end-->

	  
      <!--main content start-->
      <section id="main-content">
      
      <section class="wrapper">
                <!-- page start-->
                
				
                
				
                <div class="row">
                    <div class="col-lg-12">
                        <section class="panel">
                            <header class="panel-heading">
                                
                                لیست اخبار
                         
                            </header>
                            <table class="table table-striped table-advance table-hover">
                                <thead>
                                    <tr>
										<th>#</th>
                                        <th>عنوان</th>
                                        <th>متن خبر</th>
										<th>تاریخ / ساعت</th>
                                    </tr>
                                </thead>
                                <tbody>
                                
                                <?php
								$i=0;
								$sql = "select * from tbl_news where `to`='1' || `to`='0' order by `id` desc";
								$query = mysqli_query($con,$sql);
								while($fetch = mysqli_fetch_assoc($query))
								{
									$i++;
									echo "<tr>";
									echo "<td>".$i."</td>";
									echo "<td>".$fetch["title"]."</td>";
									echo "<td>".$fetch["text"]."</td>";
									echo "<td>".$fetch["date"]." - ".$fetch["time"]."</td>";
									
									$x=$fetch["id"];
									
									
									echo "</tr>";
								}
								
								?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                </div>
                <!-- page end-->
				
				
            </section>
            
			
            <script type="text/javascript">
				function del(id)
				{
					var x=confirm("آیا از حذف خبر اطمینان دارید؟");
					if(x==true)
					{
						window.location.href="news-delete.php?id="+id;
					}
					else
					{
						window.location.href="#";
					}
				}
			</script>
			
            
            
	  </section>
      <!--main content end-->
	  
  </section>
  

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../styles/js/jquery.js"></script>
    <script src="../styles/js/jquery-1.8.3.min.js"></script>
    <script src="../styles/js/bootstrap.min.js"></script>
    <script src="../styles/js/jquery.scrollTo.min.js"></script>
    <script src="../styles/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="../styles/js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="../styles/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="../styles/js/owl.carousel.js" ></script>
    <script src="../styles/js/jquery.customSelect.min.js" ></script>

    <!--common script for all pages-->
    <script src="../styles/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="../styles/js/sparkline-chart.js"></script>
    <script src="../styles/js/easy-pie-chart.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
