<?php
session_start();
include '../functions/connection.php';
include '../functions/func.php';
include '../functions/jdf.php';



//چک لاگین معلم
if($_SESSION['studentchklogin']!=1)
{
	header ("location:student-login.php");
	exit;	
}


$mydate=jdate('Y/n/j');
$mytime=jdate('H:i');



$sid = $_SESSION['studentid'];
$sql2 = "select * from tbl_students where id='".$sid."'";
$result2 = mysqli_query($con,$sql2);
$rows2 = mysqli_fetch_assoc($result2);

$fname2 = $rows2['fname'];
$lname2 = $rows2['lname'];
$paye2 = $rows2['paye'];
$reshte2 = $rows2['reshte'];
$tell2 = $rows2['tell'];
$fathertell2 = $rows2['father_phone_number'];
$mothertell2 = $rows2['mother_phone_number'];
$bdate2 = $rows2['bdate'];
$father2 = $rows2['father'];
$address2 = $rows2['address'];
$fatherworkaddress2 = $rows2['father_work_address'];
$motherworkaddress2 = $rows2['mother_work_address'];
$avatar2 = $rows2['image'];
$username2=$rows2['username'];
$ncode2=$rows2['ncode'];
$shomareshenasname2=$rows2['shenasname_code'];
$fullname = $fname2 . " " . $lname2;


	
?>