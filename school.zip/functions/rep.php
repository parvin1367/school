<?php


session_start();
include 'connection.php';
include 'func.php';
include 'jdf.php';


//چک لاگین
if($_SESSION['chklogin']!=1)
{
	header ("location:admin-login.php");
	exit;	
}


$mydate=jdate('Y/n/j');
$mytime=jdate('H:i');



$adminid = $_SESSION['adminid'];
$sql = "select * from tbl_admin where id='".$adminid."'";
$result = mysqli_query($con,$sql);
$rows = mysqli_fetch_assoc($result);
$fname = $rows['fname'];
$lname = $rows['lname'];
$avatar = $rows['img'];
$fullname = $fname . " " . $lname;





	
?>