<?php

$hostname = "localhost";
$dbuser = "edubaran_test";
$dbpass = "Test?123@";
$dbname = "edubaran_myschooldb";

$con = mysqli_connect($hostname,$dbuser,$dbpass,$dbname) or die ("Error in connect to Database ...");

mysqli_query($con,"SET NAMES 'UTF8'");
mysqli_query($con,"SET character_set_connection = 'utf8'");

?>