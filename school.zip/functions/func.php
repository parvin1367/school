<?php



function myPrevent($value){ 
 $str = trim($value); 
 $str = htmlspecialchars($str); 
 $str = strip_tags($str); 
 $str = addslashes($str); 
 return $str; 
}  


//xss
function myXss($value)
{
	$string1=addslashes($value);
	$string2=strip_tags($string1);
	return $string2;
}


//تبدیل به اینتیجر
function myCheckNum($value)
{
	return (int) $value;	
}


//رمز نگاری اطلاعات
function myHashData($type,$value)
{
	switch($type)
	{
		case "crypt":
			return crypt("s@j6sn9".$value."478#hg64","@56djg9$&hk!");
			
		case "sha1":
			return sha1("fhj#%545k".$value."het6jr485%j");
			
		case "md5":
			return md5("6j5s6%3wt5j".$value."t3j5s!#%&6j&!#n8");
	}
}


?>